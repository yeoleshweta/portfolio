# NLP-Based Behavioral Measurement Pipeline for Clinical Communication

## Complete Research Documentation — All Sources Consolidated

### Aligned to ACGME & ABMS Competencies, ACGME Milestones, Clinical Communication Frameworks, SLM Data Labeling Architecture, Grading Rubrics, and Co-Op Project Context

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Project Origins, Evolution, and Team Context](#2-project-origins-evolution-and-team-context)
   - 2.1 [Why the Project Was Necessary: The ABIM Mission Connection](#21-why-the-project-was-necessary)
   - 2.2 [The Problem Statement](#22-the-problem-statement)
   - 2.3 [The Proposed Solution](#23-the-proposed-solution)
   - 2.4 [Co-Op Team Structure and Roles](#24-co-op-team-structure-and-roles)
   - 2.5 [Project Evolution: From Synthetic Data to Real Transcripts](#25-project-evolution)
   - 2.6 [Co-Op Presentation Structure](#26-co-op-presentation-structure)
3. [Core Competency Frameworks: ABMS, ACGME, and ABIM](#3-core-competency-frameworks)
   - 3.1 [ABMS/ACGME Six Core Competencies](#31-abmsacgme-six-core-competencies)
   - 3.2 [ACGME Milestones System](#32-acgme-milestones-system)
   - 3.3 [ABIM's Role and Milestones Context](#33-abims-role-and-milestones-context)
   - 3.4 [ACGME Milestones 2.0 Developmental Trajectory (Dreyfus Model)](#34-acgme-milestones-20-developmental-trajectory)
4. [The 16 Nuanced Medical Skills Taxonomy](#4-the-16-nuanced-medical-skills-taxonomy)
   - 4.1 [Full Skills List with Definitions](#41-full-skills-list-with-definitions)
   - 4.2 [Five Core Skill Categories](#42-five-core-skill-categories)
   - 4.3 [Skills-to-Milestones and Competencies Mapping](#43-skills-to-milestones-and-competencies-mapping)
5. [Clinical Communication Behavior Frameworks (Complete)](#5-clinical-communication-behavior-frameworks)
   - 5.1 [Calgary–Cambridge Guide (CCG)](#51-calgarycambridge-guide)
   - 5.2 [NURSE Framework (Empathy Micro-Skills)](#52-nurse-framework)
   - 5.3 [AHRQ SHARE Approach (Shared Decision-Making)](#53-ahrq-share-approach)
   - 5.4 [SPIKES Protocol (Delivering Bad News)](#54-spikes-protocol)
   - 5.5 [Mark McLaughlin's 6-Step Assessment Framework](#55-mclaughlins-6-step-assessment)
   - 5.6 [Why Calgary-Cambridge and NURSE Were Chosen as Primary Frameworks](#56-why-ccg-and-nurse-were-chosen)
6. [Grading Rubric: Calgary–Cambridge (Full Checklist)](#6-grading-rubric-calgarycambridge)
   - 6.1 [Step 1: Build Rapport and Establish Safety](#61-step-1-build-rapport-and-establish-safety)
   - 6.2 [Step 2: Set the Agenda Collaboratively](#62-step-2-set-the-agenda-collaboratively)
   - 6.3 [Step 3: Invite the Patient's Narrative](#63-step-3-invite-the-patients-narrative)
   - 6.4 [Step 4: Structured Exploration with Explicit Signposting](#64-step-4-structured-exploration)
   - 6.5 [Step 5: Summary and Check-Back](#65-step-5-summary-and-check-back)
   - 6.6 [Step 6: Closing, Shared Plan, and Next Steps](#66-step-6-closing-shared-plan-and-next-steps)
7. [Grading Rubric: NURSE (Full Checklist)](#7-grading-rubric-nurse)
   - 7.1 [N — Name the Emotion](#71-n--name-the-emotion)
   - 7.2 [U — Understand the Emotion](#72-u--understand-the-emotion)
   - 7.3 [R — Respect the Patient](#73-r--respect-the-patient)
   - 7.4 [S — Support the Patient](#74-s--support-the-patient)
   - 7.5 [E — Explore the Emotion](#75-e--explore-the-emotion)
8. [Exhaustive Frameworks-to-Competencies Crosswalk](#8-exhaustive-frameworks-to-competencies-crosswalk)
   - 8.1 [CCG Phase-by-Phase Regulatory Alignment](#81-ccg-phase-by-phase-regulatory-alignment)
   - 8.2 [NURSE Step-by-Step Regulatory Alignment](#82-nurse-step-by-step-regulatory-alignment)
   - 8.3 [SHARE Step-by-Step Regulatory Alignment](#83-share-step-by-step-regulatory-alignment)
   - 8.4 [ICS1 Subcompetency Threads](#84-ics1-subcompetency-threads)
   - 8.5 [ICS2: Interprofessional and Team Communication](#85-ics2-interprofessional-and-team-communication)
   - 8.6 [PROF1: Professional Behavior and Ethical Principles](#86-prof1-professional-behavior-and-ethical-principles)
   - 8.7 [ABMS Competencies Integration Table](#87-abms-competencies-integration-table)
9. [Mapping Observable Behaviors to Competencies and Milestones (Master Table)](#9-mapping-observable-behaviors-master-table)
10. [Where Clinical Communication Lives in the Framework](#10-where-clinical-communication-lives)
    - 10.1 [Internal Medicine ICS1 Developmental Levels (L1–L5)](#101-ics1-developmental-levels)
11. [Mastering the Clinical Intake: Podcast Masterclass Insights](#11-mastering-the-clinical-intake)
    - 11.1 [The Three Pillars of Assessment Mastery](#111-the-three-pillars)
    - 11.2 [Physician Adaptability and Emotion Regulation](#112-physician-adaptability)
    - 11.3 [The Digital Frontier and AI](#113-the-digital-frontier)
12. [Clinical Inquiry and Pedagogy Questions](#12-clinical-inquiry-and-pedagogy-questions)
13. [Data and Labeling Pipeline: Deep Dive](#13-data-and-labeling-pipeline)
    - 13.1 [Phase 1: Synthetic Data Bootstrap (ChatNote-Style)](#131-phase-1)
    - 13.2 [Phase 2: Pivot to Real Clinician–Patient Conversations](#132-phase-2)
    - 13.3 [Phase 3: LLM-Based Labeling at Scale](#133-phase-3)
    - 13.4 [Phase 4: NER in Transcript Pipelines](#134-phase-4)
    - 13.5 [Phase 5: Downstream Model Training and Final Grading](#135-phase-5)
14. [SLM Behavior Analysis and Data Labeling Schema](#14-slm-data-labeling-schema)
    - 14.1 [Medical Jargon and Labeling Conventions](#141-labeling-conventions)
    - 14.2 [Complete CSV Labeling Schema](#142-csv-labeling-schema)
    - 14.3 [Database Querying Plan (MVD)](#143-database-querying-plan)
15. [Internal Artifacts and Source Systems](#15-internal-artifacts)
16. [Supporting Research and Evidence Base](#16-supporting-research)
17. [Assessment and Measurement Challenges](#17-assessment-challenges)
18. [Generalizability Beyond Healthcare](#18-generalizability)
19. [Practical Recommendations for Integration](#19-practical-recommendations)
    - 19.1 [Validation and Governance Steps](#191-validation-and-governance)
    - 19.2 [Recommended Metrics](#192-recommended-metrics)
    - 19.3 [Thresholding, Human-in-Loop Design](#193-thresholding)
    - 19.4 [Privacy and PHI Handling](#194-privacy-and-phi)
20. [Pipeline Architecture Visualizations](#20-pipeline-visualizations)
21. [Concrete Workflow-Specific Recommendations](#21-workflow-recommendations)
22. [Gaps, Successes, Biases, and Limitations](#22-gaps-successes-biases-limitations)
23. [Future Impact and How Future Co-Ops Can Continue](#23-future-impact)
24. [References and Sources](#24-references-and-sources)

---

## 1. Executive Summary

This document is a **single-source-of-truth consolidation** of all research, conversations, design decisions, clinical frameworks, grading rubrics, pedagogical questions, data labeling schemas, team contributions, and evidence gathered across the development of an **NLP-based behavioral measurement pipeline for clinical communication**, anchored to the ABMS/ACGME competency frameworks and ACGME Milestones system.

### The Core Problem

Currently, the only robust way to measure physician capability is through examinations that primarily assess **medical knowledge** — one of six ABMS/ACGME core competencies. The other five competencies, especially **Interpersonal & Communication Skills** and **Professionalism**, remain the hardest to measure objectively and at scale. Expert human grading of communication is the gold standard, but its high cost and time intensity mean most trainees receive limited, sporadic feedback across their entire career. There is a **massive verification gap**: we certify doctors via exam but *assume* they are capable of proper human interaction.

### The Solution

This project validates an **AI-driven model** that translates nuanced relational skills into objective, actionable data via standardized communication frameworks. The pipeline:

1. **Ingests** real clinician–patient conversation transcripts (pivoted from an initial synthetic-data approach)
2. **Labels** communication behaviors using LLM-based annotation grounded in the **Calgary–Cambridge Guide** and **NURSE** frameworks (with SHARE, SPIKES, and McLaughlin's 6-Step as additional reference frameworks)
3. **Maps** behaviors upward to **ABMS/ACGME Core Competency domains** and **ACGME Milestones subcompetencies**
4. **Trains** downstream Small Language Models (SLMs) to produce structured behavioral assessments
5. **Positions** outputs as **formative decision-support** — not standalone high-stakes judgments

### The Research Question

> **Can AI-driven pattern recognition achieve the same level of nuance and accuracy as human expert evaluation of clinical communication?**

### Key Numbers

- **~985 conversations** in the labeled dataset (real + simulated)
- **~8–10 exemplar conversations** curated per construct for few-shot prompting
- **16 nuanced medical skills** identified and mapped to milestones, narrowed to **12** that are identifiable by AI
- **Multiple LLM variants** evaluated per construct (Qwen, Llama)
- **Combined label space**: `cc_`, `nurse_`, `sh_`, `sp_`, `cr_`, `ml_`, `exam_`, `comp_`, `ksao_`

---

## 2. Project Origins, Evolution, and Team Context

### 2.1 Why the Project Was Necessary: The ABIM Mission Connection

- **Physicians are busier than ever**, leaving little room to measure or improve how they communicate with patients.
- **Certified staff lack the time** needed for direct observation and grading of trainees.
- **We lack the high-level data** needed to ensure a system-wide standard of care.
- **Without a standardized tool**, one person's "empathy" is another's "inefficiency."
- Current assessments mainly measure **medical knowledge**, but true clinical excellence also depends on *how* physicians communicate with patients.
- Expert evaluation of communication is ideal, but it is **too slow and costly** to provide trainees with regular feedback.
- Professional skills and attitudes are highly valued, yet they remain **the most difficult to measure consistently and fairly**.
- There is **no scalable way** to evaluate communication across large volumes of clinical conversations.
- The only current measures of communication are **patient satisfaction surveys** — rare and few.
- Current certification operates via **summative feedback**; the goal is to move toward **formative** assessment.
- This project aligns with ABIM's goal of ensuring diplomates demonstrate excellence in **all facets of care**, not just medical knowledge.

### 2.2 The Problem Statement

There is a massive **verification gap** in medicine. We certify doctors via examination but assume they are capable of proper human interaction. Limited ways currently exist to measure communication — only through patient satisfaction surveys which are rare and few. The current certification model relies on summative feedback; the goal is to shift toward continuous, formative feedback that enables real skill development.

### 2.3 The Proposed Solution

- **Approach**: Utilize Language Models (LMs) as an automated "second set of eyes" to provide continuous, objective observation of patient interactions.
- **The Research Question**: Can AI-driven pattern recognition achieve the same level of nuance and accuracy as human expert evaluation?
- **The Objective**: Move from subjective interpretation to objective data by providing a consistent, standardized measure for clinical communication.
- **The Ultimate Goal**: Empower diplomates with evidence-based tools to refine the relational skills proven to improve care.
- **Unit of Research**: The physician encounter (core consultation) — chosen because it is a universal encounter with applicability across all medical specialties represented by ABIM.

> *"Now that we've established the LLM as our 'second set of eyes,' the next question was: Where do we point them? We chose to focus on the core physician encounter because it is the universal heartbeat of medicine, regardless of specialty. By mapping this encounter to ACGME milestones, we move from a simple experiment to a viable assessment tool."*

### 2.4 Co-Op Team Structure and Roles

The project was executed by three Co-Op team members, each bringing distinct expertise:

**Maddie — Frameworks, Skills Mapping, and Inter-Rater Reliability**
- Reviewed immersive job analysis on the general physician job, focusing on the physician-patient intake assessment process (developing treatment plans, making diagnoses, collecting patient information, explaining procedures, discussing results)
- Specifically chose an activity applicable to multiple scenarios/specialties
- Considered the soft and nuanced medical skills present in clinical encounters
- Traced skills and behaviors to competencies (Patient Care and Interpersonal Communication)
- Found relevant frameworks (NURSE and Calgary-Cambridge) — valid, reliable, and capable of being recognized by a Language Model
- Conducted immersive analysis on frameworks
- Created checklists to determine if framework steps are present in conversations (absence vs. presence)
- Helped determine and refine AI prompts to ensure the AI was capturing the intent of each framework
- Assisted with manual grading and developing the **gold standard dataset** (high quality vs. low quality conversations)
- Focused on **Inter-Rater Reliability Analysis** — calculated consistency between human graders and the AI

**Shawn — Model Architecture and Metrics**
- Go through model and metrics
- Model evaluation and performance analysis

**Shweta — Data and Label Discussion**
- Data pipeline and label discussion
- Data processing and preparation

### 2.5 Project Evolution: From Synthetic Data to Real Transcripts

**Original Plan**: Use a HuggingFace "ChatNote-style" synthetic doctor–patient dataset, combined with manual annotation in Label Studio, to label communication behaviors and train initial models.

**The Pivot**: Recognizing that synthetic conversations can diverge from real-world distributions — reducing measurement validity — the team pivoted to real clinician–patient transcripts as primary ground truth.

**Key Decisions Along the Way**:
- Started with 16 nuanced medical skills, narrowed to **12** after considering which ones are identifiable by AI
- Initially planned to use Calgary-Cambridge, NURSE, *and* SHARE; ultimately **only followed through with Calgary and NURSE** due to time constraints
- Why these two specifically: (1) NURSE has placeholders within Calgary, making them strongly integrated; (2) Calgary accounts for the largest number of skills; (3) Together they still account for all 12 target skills; (4) Keeping SHARE instead of NURSE would have created overlap
- Created detailed checklists for both frameworks to bridge human nuance and machine logic

### 2.6 Co-Op Presentation Structure

The final presentation follows this recommended order:

1. Why was project necessary? Connect to ABIM mission
2. Where we started — how did we conclude this project was worth doing
3. Break down frameworks/research (Maddie) — why they were chosen, their benefit
4. How we pivoted data and edited prompts
5. Data and label discussion (Shweta)
6. Methodologies, Obstacles, work actually produced
7. Go through model and metrics (Shawn)
8. What we ended with — Results
9. Future impact / Real world scenario link — big picture
10. Gaps and Successes
11. Biases and Limitations
12. What we recommend not going forward with
13. How future Co-Ops can take this forward

---

## 3. Core Competency Frameworks: ABMS, ACGME, and ABIM

### 3.1 ABMS/ACGME Six Core Competencies

| # | Competency Domain | Description | Project Alignment |
|---|---|---|---|
| 1 | **Medical Knowledge** | Established and evolving biomedical, clinical, and cognate sciences | Contextual background for clinical reasoning labels (`cr_`); CCG biomedical perspective |
| 2 | **Patient Care & Procedural Skills** | Compassionate, appropriate, effective treatment; promote health and safety | SHARE labels (`sh_`); CCG history-taking and exam; exam labels (`exam_`) |
| 3 | **Practice-Based Learning & Improvement** | Investigation/evaluation of care; appraise evidence; continuous improvement | SHARE Step 2 (evidence-based aids); training covariates |
| 4 | **Systems-Based Practice** | Awareness of and responsiveness to larger healthcare system context | SHARE Step 5 (implementation barriers); CCG agenda negotiation; SBP milestones |
| 5 | **Interpersonal & Communication Skills** | Effective information exchange and teaming with patients/families/professionals | **Primary target** — CCG, NURSE, SPIKES, McLaughlin labels |
| 6 | **Professionalism** | Ethical principles; sensitivity to diversity; humanism; respectful partnerships | NURSE empathy labels; CCG relationship-building; professionalism covariates |

**Source**: [ABMS Standards for Initial Certification](https://www.abms.org/board-certification/board-certification-standards/standards-for-initial-certification/)

### 3.2 ACGME Milestones System

ACGME Milestones operationalize the six competency domains into **specialty-specific, developmental narrative descriptors** (Levels 1–5). Key characteristics:

- **Purpose**: Formative assessment, shared language, program improvement — *not* externally imposed high-stakes decisions
- **Governance caution**: ACGME explicitly states individual Milestones data "were not designed or intended" for external high-stakes decisions, warning of negative incentives and rating inflation
- **Milestones 2.0** uses more straightforward language, fewer milestones, and "harmonized" non-patient-care competencies across all specialties
- Public members on milestone development groups ensure patient perspective remains central

### 3.3 ABIM's Role and Milestones Context

ABIM describes Milestones as **outcomes-based expectations** co-convened by ACGME/ABIM/AAIM working groups, used for normative data, program improvement, and demonstrating GME accountability.

### 3.4 ACGME Milestones 2.0 Developmental Trajectory (Dreyfus Model)

| Level | Stage | Description | Communication Framework Alignment |
|---|---|---|---|
| **Level 1** | **Novice** | Rule-driven; limited ability to prioritize. May follow CCG checklist mechanically but miss non-verbal distress. NURSE usage may be scripted and unauthentic. | Basic CCG Phase I; scripted NURSE Naming |
| **Level 2** | **Advanced Beginner** | Sorts rules by experience; establishes therapeutic relationships in routine situations. Identifies emotional cues. Moves beyond introductions to agenda-setting with some fluidity. | CCG agenda negotiation; NURSE Naming + beginning Understanding; basic rapport |
| **Level 3** | **Competent** | Embraces responsibility; handles the "big picture" for common problems. Integrates I.C.E. and NURSE middle steps. Elicits understanding, values, expectations to align clinical goals. | CCG Phase II (I.C.E.) + NURSE Respecting/Supporting; basic SHARE |
| **Level 4** | **Proficient** (Graduation Target) | Comfortable with "dual process thinking"; independently manages complex situations. Leads high-stakes SDM using full SHARE approach even amid conflict or lack of consensus. | Full SHARE; SPIKES mastery; complex SDM; independent barrier mitigation |
| **Level 5** | **Expert** (Aspirational) | Role model/coach. Coaches others when behavior fails to meet standards. Identifies system-level ethical factors. Seamlessly adapts frameworks to atypical/complex environments. | Coaching others; modeling barrier mitigation; systems-level communication leadership |

**Key insight about cognitive dissonance**: Implementing Milestones assessment often encounters resistance from faculty comfortable with traditional subjective methods. The **traditionalist perspective** relies on "gut feeling" and assumes competence based on years of education. The **outcome-based perspective** relies on direct observation and objective benchmarks from frameworks like CCG and SHARE.

---

## 4. The 16 Nuanced Medical Skills Taxonomy

The project identified 16 nuanced medical skills through immersive job analysis, organized into five core categories. These were later narrowed to **12 skills** that are identifiable by AI in transcript analysis.

### 4.1 Full Skills List with Definitions

| # | Skill | Definition |
|---|---|---|
| 1 | **Emotional Regulation** | Managing one's own internal state and biases to remain present and professional during stressful encounters |
| 2 | **Empathy & Compassion** | The foundational ability to perceive, share, and act upon the patient's emotional state (navigating and responding to emotion) |
| 3 | **Behavioral Adaptability** | Dynamically adjusting communication style, tone, and energy to match the patient's personality or cultural needs |
| 4 | **Bedside Manner** | The collection of professional etiquette and physical presence (posture, eye contact) that establishes immediate rapport |
| 5 | **Strategic Agenda Setting** | Negotiating the goals of the visit early on to balance patient concerns with medical priorities |
| 6 | **Patient-Centered Interviewing** | Shifting focus from a "checklist" history to a narrative-driven dialogue where the patient's story leads |
| 7 | **Active Listening** | Engaging in a "loop" of listening, processing, and reflecting back to ensure the patient feels fully heard |
| 8 | **Nonverbal Facilitation** | Using body language, silence, and "minimal encouragers" (nodding, leaning in) to prompt the patient to continue |
| 9 | **Persistent Open-Ended Questioning** | Resisting the urge to ask Yes/No questions, using broad prompts to uncover deeper clinical data |
| 10 | **Eliciting & Navigating Context** | Specifically seeking out "real life" factors (finances, family, home) that influence patient health |
| 11 | **Indirect Emotional Inquiry** | Using subtle "door-openers" to address emotions the patient may not be stating directly |
| 12 | **Bridging Relational Gaps** | Actively working to overcome barriers caused by differences in background, education, or previous medical trauma |
| 13 | **Complex Clinical Reasoning** | High-level synthesis of medical knowledge with specific nuances and context of the individual patient |
| 14 | **Collaborative Phrasing** | Using "we" language and inclusive terminology to transition from "doctor's orders" to a partnership |
| 15 | **Shared Decision Making** | The formal process of weighing medical options against patient values to reach a mutually agreed-upon plan |
| 16 | **Relationship & Trust Building** | The deliberate cultivation of a safe, reliable, and non-judgmental space for the patient |

### 4.2 Five Core Skill Categories

| Category | Skills Included | ACGME Milestone Alignment | ABMS Competency |
|---|---|---|---|
| **The Emotional Core** | 1. Emotional Regulation, 2. Empathy & Compassion | PROF1: Professional Behavior and Ethical Principles; ICS1: Patient- and Family-Centered Communication | Professionalism: Maintaining an ethical and sensitive practice |
| **Relational Mechanics** | 3. Relationship & Trust Building, 4. Bridging Relational Gaps, 5. Bedside Manner, 6. Behavioral Adaptability | ICS1: Patient- and Family-Centered Communication; PROF1: Cultural Humility and Sensitivity | Interpersonal & Communication Skills: Creating a therapeutic relationship |
| **Information Gathering** | 7. Active Listening, 8. Persistent Open-Ended Questioning, 9. Nonverbal Facilitation, 10. Patient-Centered Interviewing | PC1: History; ICS1: Verbal and Non-verbal Communication Skills | Patient Care: Gathering accurate, context-rich data |
| **Cognitive Integration** | 11. Complex Clinical Reasoning, 12. Eliciting & Navigating Context | PC3: Clinical Reasoning & Differential Diagnosis; SBP3: System Navigation | Patient Care: Synthesizing clinical and contextual data |
| **The Collaborative Plan** | 13. Shared Decision Making, 14. Collaborative Phrasing, 15. Strategic Agenda Setting, 16. Indirect Emotional Inquiry | ICS1: Negotiating Shared Goals; SBP3: Patient-Centered System Navigation | Systems-Based Practice; Interpersonal & Communication Skills |

### 4.3 Individual Skills-to-Milestones and Competencies Mapping

| Skill | ACGME Milestone (Sub-Competency) | ABIM Core Competency |
|---|---|---|
| 1. Emotional Regulation | PROF1: Professional Behavior & Ethical Principles | Professionalism |
| 2. Empathy & Compassion | ICS1: Patient- and Family-Centered Communication | Interpersonal & Communication Skills |
| 3. Relationship & Trust Building | PROF1 / ICS1: Creating therapeutic alliances | Professionalism |
| 4. Behavioral Adaptability | PROF2: Accountability & Adaptability | Professionalism |
| 5. Bedside Manner | ICS1: Patient-centered communication | Interpersonal & Communication Skills |
| 6. Strategic Agenda Setting | ICS1: Negotiating shared goals for the visit | Interpersonal & Communication Skills |
| 7. Patient-Centered Interviewing | PC1: History; ICS1: Patient-centered interview | Patient Care / Interpersonal Skills |
| 8. Active Listening | PC1: History (gathering accurate data) | Patient Care |
| 9. Nonverbal Facilitation | ICS1: Verbal and nonverbal communication | Interpersonal & Communication Skills |
| 10. Persistent Open-Ended Questioning | PC1: History (comprehensive and nuanced) | Patient Care |
| 11. Eliciting & Navigating Context | SBP3: System Navigation for Patient-Centered Care | Systems-Based Practice |
| 12. Indirect Emotional Inquiry | ICS1: Advanced responding to emotion | Interpersonal & Communication Skills |
| 13. Bridging Relational Gaps | PROF1: Cultural humility and sensitivity | Professionalism |
| 14. Complex Clinical Reasoning | PC3: Clinical Reasoning & Differential Diagnosis | Medical Knowledge / Patient Care |
| 15. Collaborative Phrasing | ICS1: Use of inclusive/collaborative language | Interpersonal & Communication Skills |
| 16. Shared Decision Making | ICS1 / SBP3: Collaborative management | Patient Care |

---

## 5. Clinical Communication Behavior Frameworks (Complete)

### 5.1 Calgary–Cambridge Guide (CCG)

The Calgary–Cambridge Guide is the most comprehensive process model for the medical interview, dividing the consultation into six distinct phases and identifying **over 70 discrete communication behaviors**. Developed by Kurtz and Silverman, it balances the biomedical perspective with the patient's unique illness framework.

**Phase I: Initiating the Session**
- Establishing rapport, clarifying roles, greeting the patient
- **Agenda setting** (`cc_agenda_set`): Eliciting the full list of patient concerns using techniques like asking "What else?" multiple times to prevent "doorknob" questions
- Specific CCG behaviors: greeting patient, obtaining name, introducing self/role, demonstrating respect/interest, attending to comfort, using appropriate opening questions, listening attentively to opening statement, confirming list and screening for further problems, negotiating agenda

**Phase II: Gathering Information**
- Exploring biomedical perspective and patient's illness perspective
- Uses the **I.C.E. mnemonic**: Ideas (perceived cause), Concerns (biggest worry), Expectations (hopes for the visit)
- Relies on supporting the patient's narrative with uninterrupted, active listening (`cc_patient_narrative_supported`)
- Moving from open to closed questions; facilitating responses through silence or repetition; picking up non-verbal cues

**Phase III: Providing Structure**
- **Signposting** (`cc_structure_signposting`): Making organization overt through transitional statements (e.g., "Now that we've discussed the pain, I'd like to move on to your family history")
- Summarizing to maintain flow and clarity
- Consultations often fail not due to lack of empathy but due to **lack of clarity**

**Phase IV: Building the Relationship** (Continuous Thread)
- Empathy, non-judgmental acceptance, support
- Dealing sensitively with embarrassing/disturbing topics
- Sharing thinking with the patient (demystifying clinical reasoning)
- Non-verbal behavior (eye contact, posture); ensuring technology doesn't interfere

**Phase V & VI: Explanation, Planning, and Closing**
- **Chunking and checking**: Delivering information in digestible segments, checking comprehension after each
- **Safety netting** (`cc_closing_next_steps`): Explaining possible unexpected outcomes and what to do if the plan isn't working
- **Summary and check-back** (`cc_summary_checkback`): Teach-back verification
- Ensuring appropriate closure; summarizing care plan

### 5.2 NURSE Framework (Empathy Micro-Skills)

The NURSE framework provides specific **micro-skills to respond to emotional cues and build trust**. While CCG manages encounter flow, NURSE operationalizes the "soft skill" of empathy into observable behaviors.

| Letter | Micro-Skill | Label Tag | Example | Clinical Mechanism |
|---|---|---|---|---|
| **N** | Naming | `nurse_name` | "It sounds like you're worried." | Explicitly identifies emotion; signals attunement; de-escalates tension |
| **U** | Understanding | `nurse_understand` | "I can see how this is challenging." | Validates *legitimacy* of feelings; avoids paternalistic "I understand" |
| **R** | Respecting | `nurse_respect` | "You've been working really hard." | Praises resilience/coping; builds self-efficacy |
| **S** | Supporting | `nurse_support` | "We are committed to helping you." | Offers partnership/commitment; reduces isolation |
| **E** | Exploring | `nurse_explore` | "Tell me more about what's on your mind." | Open-ended emotional exploration; deepens understanding |

**Integration with frameworks**: NURSE maps to soft skills including Indirect Emotional Inquiry (Name), Eliciting & Navigating Context (Understand), Empathy & Compassion (Respect), Relationship & Trust Building (Support), and Active Listening + Persistent Open-Ended Questioning (Explore).

**Impact**: Patients who feel heard and understood are less likely to initiate litigation even when outcomes are suboptimal. NURSE at expert level (Milestone Level 5) involves employing empathic responses in high-stakes scenarios like serious illness discussions or family conflict.

### 5.3 AHRQ SHARE Approach (Shared Decision-Making)

| Step | Label Tag | Description | Soft Skill Integration | Milestone Alignment |
|---|---|---|---|---|
| **S** — Seek participation | `sh_seek_participation` | Invite patient to play active role | Collaborative Phrasing ("I'd like for us to look at options together") | ICS1: Patient-centered communication and partnership |
| **H** — Help explore options | `sh_help_compare_options` | Present options with risks/benefits | Complex Clinical Reasoning (synthesizing data into clear trade-offs) | PC3/MK: Clinical reasoning |
| **A** — Assess values | `sh_assess_values_preferences` | Explore personal values, costs, lifestyle | Active Listening + Eliciting Context | SBP3: System navigation for patient-centered care |
| **R** — Reach decision | `sh_reach_decision` | Collaborate to finalize aligned plan | Shared Decision Making ("Which path feels most right for you?") | ICS1: Establishing mutual management plan |
| **E** — Evaluate | `sh_evaluate` | Monitor implementation and barriers | Relationship & Trust Building (checking adherence/understanding) | PROF2: Accountability for patient outcomes |

**Note**: SHARE was ultimately **not included as a primary framework** in the final pipeline due to time constraints, but remains documented as a reference framework and potential future extension.

### 5.4 SPIKES Protocol (Delivering Bad News)

| Step | Label Tag | Description |
|---|---|---|
| **S** — Setting | `sp_setting` | Ensure privacy, minimize interruptions, invite support persons |
| **P** — Perception | `sp_perception` | Assess what patient already knows ("What have you been told so far?") |
| **I** — Invitation | `sp_invitation` | Ask about information preferences |
| **K** — Knowledge | `sp_knowledge_plain` | Use plain, direct language; deliver in small chunks |
| **E** — Emotion | `sp_emotion_addressed` | Address and validate emotional reactions using NURSE micro-skills |
| **S** — Strategy | `sp_strategy_summary` | Summarize plan and next steps |

### 5.5 Mark McLaughlin's 6-Step Assessment Framework

1. **Connection** — Establish rapport; build working alliance
2. **Elicit** — Gather patient's story in their own words
3. **Review** — Review prior history and treatments
4. **Physical Exam** — Conduct thorough, evidence-based exam
5. **Show/Tell** — Share findings transparently
6. **Confirm** — Close the loop with teach-back and plan acceptance (`ml_teachback_confirm`)

### 5.6 Why Calgary-Cambridge and NURSE Were Chosen as Primary Frameworks

The team's decision to focus on CCG and NURSE (dropping SHARE from active implementation) was based on several factors:

1. **Strong integration**: NURSE has natural placeholders within Calgary-Cambridge — the empathy micro-skills activate during Calgary's "Building the Relationship" phase
2. **Maximum skill coverage**: Calgary accounts for the largest number of the 12 target skills
3. **Complete coverage**: Together, CCG and NURSE still account for all 12 identifiable skills
4. **Avoiding overlap**: Keeping SHARE instead of NURSE would have created significant construct overlap
5. **Validity and reliability**: Both frameworks are evidence-based, validated, and have structures suitable for Language Model integration
6. **Three pillars addressed**: Together they cover the structural (CCG), emotional (NURSE), and collaborative (CCG closing + NURSE Support) pillars of modern practice

**The checklist approach**:
- Created checklists for both frameworks to bridge human nuance and machine logic
- Checklists solve the problem that concepts like "empathy" are too abstract for LM detection
- Creates specific **verbal markers** for the LM to identify (presence vs. absence)
- Enables **pattern matching** by the LM
- Minimizes hallucination and bias by forcing the model to look for evidence

---

## 6. Grading Rubric: Calgary–Cambridge (Full Checklist)

This is the complete, operational grading rubric used for scoring Calgary-Cambridge behaviors in clinical conversations. Each step contains specific behavioral indicators assessed on a **presence vs. absence** basis.

### 6.1 Step 1: Build Rapport and Establish Safety

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Introduces themselves and their role | — |
| ☐ | Uses or confirms the patient's preferred name and/or pronouns | — |
| ☐ | Uses a welcoming or reassuring opening statement | "I'm glad you came in today." |
| ☐ | Acknowledges patient as a person | "That sounds like it's been really frustrating for you." |
| ☐ | Signals openness to listen | "Take your time — I want to hear what's been going on." |

### 6.2 Step 2: Set the Agenda Collaboratively

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Open-ended question about concerns | "What brings you in today?" |
| ☐ | Invites additional concerns | "What else has been bothering you?" |
| ☐ | Allows multiple concerns before narrowing | "Okay, chest pain, fatigue, and trouble sleeping — anything else?" |
| ☐ | Negotiates priorities | "Which of these feels most urgent to start with?" |
| ☐ | Confirms agenda | "So today we'll focus on the chest pain and talk about sleep if time allows." |

### 6.3 Step 3: Invite the Patient's Narrative

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Open-ended narrative prompt | "Can you walk me through what first started happening?" |
| ☐ | Minimal interruption early on | — |
| ☐ | Continuers/encouragers | "Mm-hmm." / "Go on." / "I see." |
| ☐ | Allows silence or pauses | (Brief pause) "Take your time." |
| ☐ | Responds to narrative rather than redirecting | "You mentioned this started after the move — tell me more about that." |

### 6.4 Step 4: Structured Exploration with Explicit Signposting

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Explicitly announces a transition to structured questions | "I'm going to ask you some more specific questions now." |
| ☐ | Names the topic or domain before questioning | "I want to ask a few questions about your pain." |
| ☐ | Uses sequential or ordered language | "First, let's talk about when this started." / "Next, I'd like to ask about how this affects your daily life." |
| ☐ | Frames questions as part of an organized assessment | "To get a clearer picture, I need to ask about your sleep and stress levels." |
| ☐ | Maintains clinician control of topic flow | "We'll come back to that in a moment — right now I want to focus on your medications." |

### 6.5 Step 5: Summary and Check-Back

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Summarizes medical content | "So the headaches started about three months ago and happen mostly in the mornings." |
| ☐ | Summarizes emotional/personal content | "And it sounds like they've been making work really hard and increasing your stress." |
| ☐ | Reflective/paraphrased language | "What I'm hearing is that this has been building up over time." |
| ☐ | Checks accuracy | "Did I get that right?" |
| ☐ | Invites correction or additions | "Is there anything important I missed?" |

### 6.6 Step 6: Closing, Shared Plan, and Next Steps

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Signals the visit is moving toward closure | "Before we wrap up today…" / "Let's talk about next steps." |
| ☐ | Proposes or confirms a plan of action | "I'd recommend starting physical therapy and adjusting your medication." |
| ☐ | Invites patient input or agreement on the plan | "How does that plan sound to you?" / "Does that feel manageable?" |
| ☐ | Explains next steps or follow-up logistics | "We'll schedule a follow-up in four weeks, and I'll call you with the lab results." |
| ☐ | Checks understanding or readiness before ending | "Can you tell me what the plan is so I know we're on the same page?" / "Any questions before we finish?" |

---

## 7. Grading Rubric: NURSE (Full Checklist)

This is the complete, operational grading rubric used for scoring NURSE empathy behaviors. Each step contains multiple behavioral indicators with specific verbal markers that the LM is trained to detect.

### 7.1 N — Name the Emotion

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Uses a direct "Emotion Word" — directly names the emotion | "You seem anxious." / "I can see that you are feeling frustrated with how long this is taking." / "It sounds like you're quite worried about the surgery." |
| ☐ | Employs tentative "Softener" phrases to propose an emotion | "It sounds like you might be feeling a bit overwhelmed." / "I'm sensing some hesitation or perhaps some anxiety about this plan." |
| ☐ | Directly attributes/links emotion to a clinical event (diagnosis, symptom) | "You seem upset about these test results." / "It's natural to feel scared when we talk about starting insulin." |
| ☐ | Avoids judgmental adjectives — uses neutral or empathetic labels | "This sounds like a difficult situation to be in." / "It's understandable that you'd feel uneasy right now." / "This sounds scary." |
| ☐ | Echoes/Mirroring — repeats the patient's own emotional words (MUST be related to pain or emotion itself) | Patient: "I'm overwhelmed." → Clinician: "Overwhelmed, I hear that." / Patient: "It's all very confusing." → Clinician: "Confusing, yes, there is a lot of information to take in." |

### 7.2 U — Understand the Emotion

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Uses "Legitimation" phrases — explicitly states "It makes sense," "I can see why," "That is understandable" | "It makes total sense that you would feel that way." / "I can certainly see why that would be a lot to handle." |
| ☐ | Normalizes the reaction — compares to broader human experience | "Anyone in your shoes would feel this way." / "Most people in your situation would feel exactly the same." |
| ☐ | Contextualizes the feeling — references patient's specific history/timeline to justify the emotion | "Given everything you've dealt with this month, your reaction is very logical." / "Considering how much pain you've been in, it's no wonder you're feeling low." |
| ☐ | Provides a non-interruptive acknowledgment — allows patient to finish emotional expression before responding | "I hear you. Please, take your time... [Patient continues] ...I understand." / "Mhm, I see. I'm listening... Thank you for sharing that with me." |
| ☐ | Uses patient-centered framing — uses patient's own logic to explain why the emotion "fits" | "From what you've described, it sounds like your frustration is really well-founded." / "Based on your experience last time, I can see why you're feeling cautious." |

### 7.3 R — Respect the Patient

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Labels/acknowledges a specific "Proactive" behavior — commends patient for a specific action | "You did the right thing by coming in." / "You've been very proactive about tracking your blood pressure." / "I'm glad you have decided to…" |
| ☐ | Acknowledges "Patient Burden" — recognizes the difficulty of patient's tasks | "I know how hard you've worked on this diet." / "You've really put in the time to follow this treatment plan." |
| ☐ | Verbalizes appreciation for transparency — explicitly thanks for sharing difficult information | "I really appreciate you being so open with me about your concerns." / "Thank you for being so honest about the challenges you're facing at home." |
| ☐ | Identifies internal resilience — uses language highlighting patient's character | "You're being very brave/strong/patient." / "You've handled this with a lot of grace and patience." |
| ☐ | Highlights the patient's "Value System" — frames positively what patient cares about | "It's clear how much your family's well-being matters to you." / "That tells me that you are doing your absolute best for your health." |

### 7.4 S — Support the Patient

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Uses "Collaborative"/Inclusive language — frequent use of "We," "Us," "Together" | "Let's figure this out as a team." |
| ☐ | Explicitly states availability — verbal commitment for future needs | "I will be here." / "Call me anytime." / "Please call me directly if your symptoms change at all." |
| ☐ | Avoids empty reassurance but signals continued presence | "I can't promise it'll be easy, but I can promise support." / "You don't have to carry this alone; we're going to work through it together." |
| ☐ | Commits to a Concrete Next Step — offers specific, immediate action | "I'll make sure the nurse gets that paperwork started." / "I'm going to go talk to the pharmacist right now to clear this up." / "I'll send that referral to the specialist before you even leave today." |
| ☐ | Verbalizes a "Joint Plan" — explicitly links next clinical step to patient's input | "Based on what you've told me, how do you feel about this next step?" / "Does this schedule work for your lifestyle, or should we adjust it?" / "I'd like to suggest this treatment, but I want to know what you think first." |

### 7.5 E — Explore the Emotion

| # | Behavioral Indicator | Example Language |
|---|---|---|
| ☐ | Uses "Emotion-Seeking" prompts | "Can you tell me more about what's been on your mind?" / "Tell me more about how you've been feeling lately." / "What's that like for you?" |
| ☐ | Explores the 'why' behind the feeling | "What about this feels the most frightening to you?" / "What is the biggest concern you have when you think about the future?" |
| ☐ | Explores "Functional/Life Impact" — asks how emotion affects day-to-day life/relationships | "How is this stress affecting your sleep or your work?" / "Is this worry keeping you from doing the things you usually enjoy?" |
| ☐ | Encourages reflection rather than facts | "What's been the hardest part of this journey for you, emotionally?" / "How has this been weighing on your spirit lately?" |
| ☐ | Keeps focus on emotion, not symptoms | "When you think about this, what feelings come up?" / "Moving past the physical pain for a moment, what feelings come up for you?" / "When we talk about the diagnosis, what is the main emotion you're noticing?" |

---

## 8. Exhaustive Frameworks-to-Competencies Crosswalk

This section provides the detailed regulatory alignment mapping from the Communication Frameworks to Competencies report.

### 8.1 CCG Phase-by-Phase Regulatory Alignment

#### Phase I: Initiating the Session

| CCG Behavior | Clinical Mechanism | Regulatory Alignment |
|---|---|---|
| Greets patient and obtains name | Establishes human connection; confirms identity | ICS-1 Level 1: Introductions and basic rapport |
| Introduces self, role, nature of interview | Clarifies authority; sets visit context | PROF-2: Accountability and role identification |
| Demonstrates respect/interest; attends to comfort | Reduces anxiety; promotes safe environment | ABMS Professionalism: Sensitivity to patient needs |
| Uses appropriate opening question | Facilitates narrative without premature closure | ICS-1 Level 2: Eliciting patient concerns |
| Listens attentively to opening statement | Prevents loss of critical diagnostic information | ABMS Interpersonal Skills: Effective listening |
| Confirms list, screens for further problems | Prevents "doorknob" concerns; improves efficiency | SBP-2: System navigation and time management |
| Negotiates agenda with patient | Aligns physician and patient goals; increases agency | Patient Care: Fostering patient-centered care |

#### Phase III & IV: Providing Structure and Building Relationship

| CCG Behavior | Clinical Implication | Milestone Alignment |
|---|---|---|
| Non-verbal behavior (eye contact, posture) | Conveys presence beyond verbal narrative | ICS-1: Relationship building thread |
| If using computer, ensure no interference | Mitigates "third party" effect of technology | PROF-2: Accountability and attention to detail |
| Provides support, expresses willingness to help | Builds trust; fosters collaborative alliance | PROF-1: Compassion and integrity |
| Deals sensitively with embarrassing topics | Maintains dignity; encourages honest disclosure | PROF-1 Level 3: Professionalism in complex situations |
| Shares thinking with the patient | Demystifies clinical reasoning; invites input | ICS-1 Level 3: Eliciting understanding and values |

#### Phase V & VI: Explanation, Planning, and Closing

- **Chunking and checking** → ICS-1 Level 4: Facilitating complex decisions, ensuring patient understanding
- **Safety netting** → SBP-1: Patient safety and clinical risk management
- **Closing summary** → ABMS: Effective information exchange; comprehensive medical records (oral)

### 8.2 NURSE Step-by-Step Regulatory Alignment

| NURSE Step | Behavioral Examples | Clinical Context | ACGME Milestone |
|---|---|---|---|
| **Naming** | "You seem worried about the results." | Acknowledging fear during diagnostic talk | ICS-1 Level 2: Identifying cues |
| **Understanding** | "I can only imagine how hard this is." | Responding to chronic illness news | PROF-1 Level 3: Professionalism |
| **Respecting** | "I'm impressed by your independence." | Praising patient self-care | ABMS: Demonstrating humanism |
| **Supporting** | "We are committed to helping you." | Offering treatment partnership | PROF-1: Responsiveness to needs |
| **Exploring** | "Tell me more about what you're feeling." | Deepening complex issue narrative | ICS-1 Level 3: Values elicitation |

### 8.3 SHARE Step-by-Step Regulatory Alignment

| SHARE Step | Specific Communication Behaviors | Regulatory Alignment |
|---|---|---|
| **Seek** | Summarize health problem; invite participation | PROF-1: Respect for patient autonomy |
| **Help** | List options; describe benefits/risks in plain language | ICS-1: Addressing communication barriers |
| **Assess** | Ask about values (e.g., out-of-pocket costs) | ICS-1 Level 3: Aligning goals with treatment |
| **Reach** | Ask if ready to decide; confirm the choice | Patient Care: Patient-centered decision-making |
| **Evaluate** | Monitor implementation; assist with barriers | SBP-2: System navigation and care coordination |

### 8.4 ICS1 Subcompetency Threads

The ICS-1 subcompetency divides into three fundamental threads:

1. **Relationship Building**: Traces development from Level 1 (basic introductions) to Level 4 (independent management of complex relationships). CCG greeting/introducing behaviors (items 1-3) are primary Level 1-2 indicators. NURSE empathy statements reach Level 3-4.

2. **Barriers to Communication**: Identifying personal and situational stressors. SHARE's health literacy focus and interpreter services map to Level 2-3 behaviors.

3. **Eliciting Understanding and Values**: The heart of shared decision-making. Level 1 is basic data gathering; Level 3 requires aligning goals with treatment. CCG's I.C.E. model and SHARE Step 3 (Assess values) are the behavioral benchmarks.

### 8.5 ICS2: Interprofessional and Team Communication

- **Consultations**: Level 1 = requesting/providing consultation; Level 4 = proficient use of health record to convey complex clinical reasoning. CCG "sharing thinking" and "explaining rationale" are critical behaviors.
- **Team Dynamics**: Adjusting communication within team settings. Satisfies ABMS requirement to "work effectively as a member or leader of a healthcare team."

### 8.6 PROF1: Professional Behavior and Ethical Principles

- **Professional Behavior**: Level 1 requires identifying triggers for professionalism lapses (fatigue, high workload). NURSE's "Exploring" phase can serve as self-reflection tool.
- **Ethical Principles**: Informed consent, confidentiality, stewardship. SHARE's autonomy emphasis and Step 2 (discussing limitations) address informed consent.

### 8.7 ABMS Competencies Integration Table

| ABMS Competency | Core Focus | Integrated Framework Behaviors |
|---|---|---|
| Patient Care | Compassionate, effective; promote health/safety | CCG: History taking and physical exam; SHARE: Decision-making |
| Medical Knowledge | Biomedical and social-behavioral sciences | CCG: Biomedical perspective and causation explanation |
| Interpersonal Skills | Effective information exchange and teaming | CCG: Rapport, listening, summarizing; NURSE: Empathy statements |
| Professionalism | Ethical principles; sensitivity to diversity | NURSE: Respecting and Supporting; CCG: Demonstrating respect |
| Systems-Based Practice | Awareness/responsiveness to healthcare systems | SHARE Step 5: Managing implementation barriers |
| Practice-Based Learning | Investigate/evaluate care; appraise evidence | SHARE Step 2: Utilizing evidence-based aids |

---

## 9. Mapping Observable Behaviors to Competencies and Milestones (Master Table)

| Observable Behavior | Framework Tag(s) | Primary Competency Domain | Milestones Anchor |
|---|---|---|---|
| Sets agenda; confirms concern list | `cc_agenda_set` | ICS | ACGME-I ICS1: "setting the agenda" |
| Respectful language / rapport-building | `cc_opening` | ICS; Professionalism | US IM ICS1 Level 1: respect/rapport |
| Supports patient narrative / active listening | `cc_patient_narrative_supported` | ICS | CCG Phase II; foundational behavior |
| Signposting for encounter structure | `cc_structure_signposting` | ICS | CCG Phase III |
| Names emotion | `nurse_name` | Professionalism; ICS | ICS-1 Level 2: Identifying cues |
| Shows understanding / validation | `nurse_understand` | Professionalism; ICS | ICS1 L2–L3: therapeutic relationship |
| Expresses respect for patient coping | `nurse_respect` | Professionalism; ICS | ABMS: Demonstrating humanism |
| Offers support / partnership | `nurse_support` | Professionalism; ICS | PROF-1: Responsiveness to needs |
| Explores emotions (open-ended) | `nurse_explore` | ICS | ICS-1 Level 3: Values elicitation |
| Elicits values/preferences/goals | `sh_assess_values_preferences` | Patient Care; ICS | ACGME-I ICS1: eliciting values |
| Compares options with risks/benefits | `sh_help_compare_options` | Patient Care; ICS | US IM ICS1 Level 4: SDM |
| Summarizes and checks back | `cc_summary_checkback` | ICS | ACGME-I ICS1: verifying understanding |
| Closes with next steps / safety-netting | `cc_closing_next_steps` | Patient Care; ICS | ICS1 higher-level proficiency |
| Ensures privacy for bad news | `sp_setting` | Professionalism; ICS | Environmental competence |
| Uses plain language | `sp_knowledge_plain` | ICS | Health literacy management |
| Confirms via teach-back | `ml_teachback_confirm` | ICS | McLaughlin Step 6 |
| Diagnostic parsimony | `cr_diagnostic_parsimony` | Medical Knowledge; Patient Care | Clinical reasoning quality |
| Targeted exam maneuvers | `exam_targeted_vs_shotgun` | Patient Care | Exam quality over quantity |

---

## 10. Where Clinical Communication Lives in the Framework

### 10.1 Internal Medicine ICS1 Developmental Levels (L1–L5)

| Level | Description | Key Behavioral Descriptors |
|---|---|---|
| **Level 1** | Foundational | Respect/rapport basics; fundamental communication courtesies |
| **Level 2** | Developing | Therapeutic relationship in straightforward encounters; identifying emotional cues |
| **Level 3** | Proficient | Therapeutic relationship in challenging encounters; identifies complex barriers; elicits understanding/values/expectations |
| **Level 4** | Advanced | **Shared decision-making regardless of complexity; mitigates communication barriers** |
| **Level 5** | Expert | Coaches others; models barrier mitigation for peers and learners |

---

## 11. Mastering the Clinical Intake: Podcast Masterclass Insights

### 11.1 The Three Pillars of Assessment Mastery

**Pillar 1: The Cognitive Engine** — Internal clinical reasoning combining fast pattern-matching (System 1) with slow deductive thinking (System 2). Incorporates **diagnostic parsimony** (`cr_diagnostic_parsimony`) and **stop rules** (`cr_stop_rules_applied`).

**Pillar 2: The Essential Skill Set** — External communication requiring active listening (the engine for efficiency), structuring, empathetic interruption, and choice architecture.

**Pillar 3: The Foundational Layer** — The Working Alliance. Trust is the essential lubricant. Requires shifting from paternalistic to collaborative partnership with explicit agreement on bond, goals, and tasks.

### 11.2 Physician Adaptability and Emotion Regulation

- **Patient-centeredness = behavioral adaptability** — altering style to match patient's competence and preferences
- **Emotion regulation** — the hidden clinical skill. Unmanaged physician emotion leads to negative emotion transfer, undermining trust and objectivity

### 11.3 The Digital Frontier and AI

- Technology must shift from barrier ("cold spot") to relational facilitator
- AI assists by offloading cognitive load through **structured SOAP note creation** and pattern identification
- The unautomatable core remains **human connection** — exactly what this pipeline measures

---

## 12. Clinical Inquiry and Pedagogy Questions

1. What is your internal mental checklist for a chief complaint?
2. How do you balance interrupting vs. allowing uninterrupted speech?
3. What cues signal the patient is finished with their main concern?
4. How do you move vague symptoms toward specific details?
5. How do initial questions shape differential diagnosis and surface fears?
6. How is uncertainty communicated while maintaining trust?
7. What empathy statements are used for difficult information?
8. What framework (SOAP, ICE) is used to teach assessment structure?
9. What is the most common student mistake, and how is it coached?
10. How is the *purpose* of exam steps taught over pure memorization?
11. What belongs on a checklist vs. a global rating?
12. How is "sufficient data" determined without losing clinical focus?
13. How much questioning variability is acceptable?
14. How are multiple issues balanced against time constraints?
15. How is patient understanding gauged without condescension?
16. How are psychosomatic complaints redirected to actionable data?
17. What is the internal "pause" process before finalizing the Assessment and Plan?

> **Open item**: Acquire **"Eric's rubric"** on how medical students are graded/passed — to be integrated as an additional validation anchor.

---

## 13. Data and Labeling Pipeline: Deep Dive

### 13.1 Phase 1: Synthetic Data Bootstrap (ChatNote-Style)

Original plan: Use HuggingFace "ChatNote-style" dataset + Label Studio annotation. NoteChat generates synthetic clinical dialogues via LLM roleplay modules. Useful for bootstrapping but limited by distribution shift from real interactions.

### 13.2 Phase 2: Pivot to Real Clinician–Patient Conversations

The pivot was driven by: distribution shift risk, model collapse concerns (Shumailov et al., Nature 2024), rubric interpretation sensitivity, and construct validity requirements. Current dataset: **~985 conversations** (real + simulated).

### 13.3 Phase 3: LLM-Based Labeling at Scale

- **~8–10 exemplar conversations** per construct for few-shot prompting
- Rubric-grounded prompts encoding formal definitions
- Per-construct model selection (Qwen vs. Llama)
- Prompts refined iteratively to ensure AI captures intent of each framework
- **Checklists** (Sections 6 and 7) serve as the bridge between human nuance and machine logic

### 13.4 Phase 4: NER in Transcript Pipelines

NER-style PHI tagging/redaction required for real clinical transcripts. Gold standard: i2b2/UTHealth 2014 de-identification corpus (double annotation + adjudication under HIPAA).

### 13.5 Phase 5: Downstream Model Training and Final Grading

- Multi-label classification (behaviors co-occur)
- Ordinal scoring for quality gradients
- Aggregation to encounter-level behavioral profiles and final grades (1–5 scale)
- **Inter-Rater Reliability Analysis** between human graders and AI (Maddie's focus)
- Gold standard dataset created via manual grading (high quality vs. low quality conversations)

---

## 14. SLM Behavior Analysis and Data Labeling Schema

### 14.1 Labeling Conventions

| Prefix | Framework | Scope |
|---|---|---|
| `cc_` | Calgary–Cambridge | Interview flow and structure |
| `nurse_` | NURSE | Empathy micro-skills |
| `sh_` | SHARE | Shared decision-making |
| `sp_` | SPIKES | Bad news delivery |
| `cr_` | Clinical Reasoning | Clinician cognitive processes |
| `ml_` | McLaughlin | Assessment framework steps |
| `exam_` | Physical Exam | Exam quality |
| `comp_` | ABMS/ACGME Competency | Domain scores (1–5) |
| `ksao_` | KSAO Indicators | Knowledge, Skills, Abilities, Other |

### 14.2 Complete CSV Labeling Schema

**Section 1: Keys and Provenance** — `item_id`, `source` (meditod | ehrshot | abim_db), `clinician_key`, `patient_key`, `datetime`, `rubric_version`, `rater_role`, `rater_confidence`

**Section 2: Global Outcomes** — `final_grade` (1–5), `communication_overall`, `empathy_overall`, `shared_decision_overall`, `professionalism_overall`

**Section 3: Behavioral Features** — All individual labels from all frameworks

**Section 4: Competency/KSAO Alignment** — `comp_professionalism`, `comp_patient_care`, `comp_ics` (1–5); `ksao_identifies_problems`, `ksao_relationship_mgmt`, `ksao_documentation_quality`

**Section 5: Weak-Label Covariates** — `survey_count`/`avg_score`, `incident_count`, `profile_note_count`, `training_recency_days`, `visit_duration_min`, `is_telemed`

### 14.3 Database Querying Plan (MVD)

| Table Category | Tables | Purpose |
|---|---|---|
| Encounters & Scheduling | `encounters`, `appointments` | Baseline denominators, durations |
| Clinical Notes/Transcripts | `clinical_notes`, `note_sections` | Source text for NLP labeling |
| Orders, Diagnoses, Exam Findings | `diagnoses`, `orders`, `exam_findings` | Link exam behaviors to testing cascades |
| Outcomes & Utilization | `ed_returns`, `readmissions`, `costs` | Communication → safety/efficiency outcomes |
| Patient-Reported Experience | `patient_surveys` | Perceived empathy measurement |
| Compliance/Risk | `consent_logs`, `chaperone_logs` | Environmental standards |
| Clinician Training | `training_records` | Training → behavior → outcomes chain |

---

## 15. Internal Artifacts and Source Systems

| System | Artifact | Content |
|---|---|---|
| **GitHub** | `ABIM-ETD/competency-map` — `README.md`, `config/import_map.yaml` | Competency mapping app; Excel-to-database column mappings |
| **SharePoint** | `MASTER Milestones 2 with Definitions and Harmonized 20250818.xlsx` | Master milestones workbook |
| **SharePoint** | `Labelling_BehaviorAnalysis.docx` (ETD-RF AI Behavior Analysis folder) | Full label ontology with ABMS/ACGME alignment fields |
| **SharePoint** | `Project summary.docx` | Original ChatNote-style plan + Label Studio workflow |
| **Monday.com** | Searched ("ChatNote", "NURSE") | No relevant artifacts returned |

---

## 16. Supporting Research and Evidence Base

### Synthetic vs. Real Transcripts
- **NoteChat** — synthetic clinical dialogue generation; implicitly acknowledges real data scarcity
- **Model collapse** (Shumailov et al., Nature 2024) — recursive synthetic data degrades distributional tails

### LLMs as Annotators
- Can match/exceed crowd-worker agreement with cost/time savings
- Agreement with experts is moderate; bias replication possible
- Best practices: silver-grade labels; per-construct validation; bias monitoring

### NER-Based De-Identification
- i2b2/UTHealth 2014 corpus: gold standard (double annotation, adjudication, HIPAA compliance)

### NLP-Screened Human Abstraction
- JAMA Network Open: NLP-assisted abstraction for goals-of-care drastically reduced manual hours while maintaining sensitivity

### Automated Evaluation of Physician Communication
- Prostate cancer consultation study: grading quality using top 10 sentences achieved feasibility/accuracy balance

### Cognitive Dissonance in Assessment Implementation
- ACGME guidance: use cognitive dissonance to create urgency for moving from subjective "gut feeling" evaluation to objective framework-based assessment

---

## 17. Assessment and Measurement Challenges

- **Construct subjectivity**: Empathy, rapport, SDM are context-dependent and expressed in many linguistic forms
- **Resource intensity**: High-quality manual assessment is expensive
- **False precision risk**: Automated scores can mask uncertainty
- **High-stakes coupling**: ACGME warns against coupling Milestones to high-stakes decisions
- **Fairness concerns**: Models may perform differently across demographic groups
- **Faculty resistance**: Traditionalist perspective vs. outcome-based perspective requires change management

---

## 18. Generalizability Beyond Healthcare

The pipeline architecture transfers to any domain with rubric-defined behavioral assessment of unstructured dialogue: legal depositions, customer support, education/advising, therapy/coaching.

---

## 19. Practical Recommendations for Integration

### 19.1 Validation and Governance Steps

1. Define construct validity explicitly (rubric-to-milestone mapping)
2. Create stratified, human-coded gold set (oversample rare positive contexts)
3. Use "NLP-screened human review" for higher-stakes outputs
4. Do not position automated grades as "Milestones ratings" — treat as evidence signals for CCC discussions

### 19.2 Recommended Metrics

| Category | Metrics | Purpose |
|---|---|---|
| Classification | Per-class Precision, Recall, F1 | Catch failure on rare classes |
| Summary | Macro-F1 | Imbalance-robust headline |
| Error Analysis | Confusion matrices | Ordinal error patterns |
| Annotation Quality | IAA (LLM vs. human) | Silver-vs-gold gap |
| Calibration | ECE, Brier score | Threshold reliability |
| Fairness | Slice-based F1 | Detect systematic bias |

### 19.3 Thresholding, Human-in-Loop Design

| Tier | Condition | Action |
|---|---|---|
| Auto-accept | High confidence + low-risk construct | Accept automatically |
| Human review | Low confidence / high stakes / subjective construct | Route to reviewer |
| Escalation | Fairness gap > threshold | Trigger bias audit |

### 19.4 Privacy and PHI Handling

NER-based de-identification (i2b2 methodology), strict access controls, audit logs, documented data flows, consent alignment with IRB.

---

## 20. Pipeline Architecture Visualizations

### Validation and Deployment Pipeline

```
┌─────────────────────────────────────────┐
│  1. Define constructs + rubric          │
│     (CCG/NURSE checklists)              │
│     + milestone anchors                 │
│     + 16 skills taxonomy                │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  2. Collect transcripts (~985)          │
│     real + simulated                    │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  3. NER-based preprocessing             │
│     PHI de-id + structure tags          │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  4. Curate 8–10 exemplar conversations  │
│     per construct + rubric-grounded     │
│     prompt engineering                  │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  5. LLM labeling at scale               │
│     Qwen/Llama best-of per construct    │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  6. Gold set human annotation           │
│     (stratified sample)                 │
│     + Inter-Rater Reliability Analysis  │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  7. Evaluate label quality              │
│     per-class F1 + IAA + bias slices    │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  8. Train downstream SLM                │
│     multilabel/ordinal scoring          │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  9. Calibrate + set tiered thresholds   │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  10. Deploy decision support            │
│      auto / human-review / escalation   │
└──────────────┬──────────────────────────┘
               ▼
┌─────────────────────────────────────────┐
│  11. Ongoing monitoring                 │
│      drift + fairness + revalidation    │
└─────────────────────────────────────────┘
```

### End-to-End Data Flow

```
Raw Transcript → NER De-ID → LLM Labeling → SLM Scoring → Behavioral Profile
    (PHI)         (Clean)     (Silver labels)  (Final grades)   (cc_*, nurse_*,
                                                                  sh_*, sp_*, cr_*,
                                                                  exam_*, comp_*,
                                                                  ksao_*)
                                                                      │
                                                                      ▼
                                                              Decision Support
                                                              → CCC Discussion Input
                                                              → Coaching Feedback
                                                              → Longitudinal Tracking
                                                              → Program Analytics
```

---

## 21. Concrete Workflow-Specific Recommendations

1. **Treat LLM labels as silver-grade** — validate against adjudicated human gold set
2. **Justify per-construct model selection with metrics** — rare constructs can fail silently under aggregate metrics
3. **Design transparent aggregation model for "final grades"** — weighted rubric score with rationale; validate against external criteria (OSCE, OPTION5/SDM tools, CCC judgments)
4. **Position as scalable feedback infrastructure** — support, don't replace, competency committees
5. **Plan for ongoing monitoring** — drift, fairness degradation, calibration decay
6. **Integrate weak-label covariates** — visit duration, satisfaction, incidents, training recency
7. **Pursue "Eric's rubric"** — integrate as additional validation anchor
8. **Use the detailed checklists (Sections 6-7) as the definitive prompt engineering reference** — each behavioral indicator maps to specific verbal markers the LM should detect

---

## 22. Gaps, Successes, Biases, and Limitations

### Identified Gaps
- SHARE framework was scoped out due to time constraints — future work should reintegrate
- 4 of 16 original skills were dropped (those not identifiable by AI in text transcripts)
- "Eric's rubric" not yet obtained
- Newer pipeline details (pivot to real transcripts, LLM labeling for 985 conversations, exemplar selection, Qwen/Llama selection) were team-described but not yet formally documented in internal systems

### Known Biases and Limitations
- LLM annotation can reproduce biases present in training data
- Synthetic data used for bootstrapping may not represent real-world distributional tails
- NER-based de-identification is imperfect — residual PHI risk must be managed
- Nonverbal behaviors (body language, eye contact, tone) are invisible in text transcripts — a fundamental limitation of transcript-based analysis
- Cultural and linguistic variation may cause differential model performance across patient populations
- The pipeline measures what is *said*, not what is *meant* — pragmatic intent can differ from literal text

### What to Recommend NOT Going Forward With
- Do not use the pipeline for high-stakes certification decisions without rigorous validation
- Do not rely solely on synthetic data for ground truth
- Do not use aggregate metrics alone for model selection — per-construct evaluation is essential

---

## 23. Future Impact and How Future Co-Ops Can Continue

### Real-World Scenario Link
- The pipeline provides a potential solution for the massive verification gap in medicine
- Moving from summative to formative feedback at scale
- Data-driven insights into communication that can improve clinical outcomes
- A "second set of eyes" that is always available, consistent, and scalable

### How Future Co-Ops Can Build on This Work
1. **Reintegrate SHARE** as a third active framework with its own grading rubric
2. **Expand the gold standard dataset** with additional manually graded conversations
3. **Validate against external criteria** (OSCE scores, patient outcomes, CCC judgments)
4. **Extend to additional specialties** beyond internal medicine
5. **Explore multimodal inputs** (audio tone, speech rate, pauses) to capture nonverbal dimensions
6. **Build the coaching feedback layer** — translating behavioral profiles into actionable development recommendations
7. **Integrate with EHR systems** for real-time or near-real-time feedback loops
8. **Conduct formal bias audits** across patient demographics and encounter types
9. **Obtain and integrate "Eric's rubric"** as an additional validation anchor
10. **Publish findings** to contribute to the broader literature on automated clinical communication assessment

---

## 24. References and Sources

### Official Standards and Frameworks
1. ABMS Standards for Initial Certification — https://www.abms.org/board-certification/board-certification-standards/standards-for-initial-certification/
2. ACGME-I Milestones Overview — https://www.acgme-i.org/accreditation-process/milestones/
3. ACGME Position on High-Stakes Use — https://www.acgme.org/globalassets/PDFs/Milestones/UseofIndividualMilestonesDatabyExternalEntitiesforHighStakesDecisions.pdf
4. US IM Milestones (v2.1) — https://www.acgme.org/globalassets/pdfs/milestones/internalmedicinemilestones.pdf
5. ACGME-I IM Milestones (v2.0) — https://www.acgme-i.org/globalassets/acgme-international/milestones-2.0/internalmedicinemilestones2.0int.pdf
6. ABIM Milestones — https://www.abim.org/program-directors-administrators/milestones
7. Milestones Guidebook for Residents/Fellows — https://www.acgme.org/globalassets/pdfs/milestones/milestonesguidebookforresidentsfellows.pdf
8. The Milestones Guidebook — https://www.acgme.org/globalassets/milestonesguidebook.pdf
9. Milestones 2.0: A Step Forward — https://www.acgme.org/globalassets/pdfs/milestones/milestones2.0astepforward.pdf
10. Rationale for Milestones — https://www.acgme.org/globalassets/pdfs/milestones/rationaleformilestones2022.pdf
11. Harmonizing ICS — https://www.acgme.org/globalassets/pdfs/milestones/harmonizingics.pdf
12. Harmonizing Professionalism — https://www.acgme.org/globalassets/pdfs/milestones/harmonizingprof.pdf
13. IM Milestones 2.0 — https://www.acgme.org/globalassets/PDFs/Milestones/InternalMedicineMilestones2.0.pdf
14. Guidebook for Implementing Assessment in Milestones Era — https://www.acgme.org/globalassets/milestones-implementation-2020.pdf

### Communication Behavior Frameworks
15. Calgary–Cambridge Guide (Silverman et al.) — https://pubmed.ncbi.nlm.nih.gov/8736242/
16. CCG Process Document — https://doctorsspeakup.com/sites/default/files/CCG%20Process.pdf
17. CCG Quick Reference — https://www.bradfordvts.co.uk/wp-content/onlineresources/communication-skills/teach-communication-skills/calgary-cambridge/04b%20calgary%20cambridge%20guide%20quick%20reference%20guide.pdf
18. VitalTalk NURSE Framework — https://vitaltalk.org/responding-to-emotion-respecting/
19. NURSE Empathy Statements (Ellis CME) — https://www.elliscme.com/uploads/9/1/9/0/91901496/handout_ford_grand_rounds.pdf
20. AHRQ SHARE Approach — https://www.ahrq.gov/es/health-literacy/curriculum-tools/shareddecisionmaking/tools/sharefactsheet/index.html
21. SHARE Quick Reference Guide — https://medschool.cuanschutz.edu/docs/librariesprovider294/default-document-library/share1_final.pdf
22. SHARE Expanded Reference — https://medschool.cuanschutz.edu/docs/librariesprovider294/default-document-library/SHARE2_final.pdf

### Synthetic Data and Distribution Shift
23. NoteChat: Synthetic Clinical Dialogues — https://aclanthology.org/2024.findings-acl.901/
24. Shumailov et al. — Model Collapse (Nature 2024) — https://www.nature.com/articles/s41586-024-07566-y

### LLMs as Annotators
25. Brown et al. — GPT-3 (NeurIPS 2020) — https://papers.nips.cc/paper/2020/hash/1457c0d6bfcb4967418bfb8ac142f64a-Abstract.html
26. LLMs as Effective Annotators — https://pmc.ncbi.nlm.nih.gov/articles/PMC10372638/
27. LLM Annotation Survey (EMNLP 2024) — https://aclanthology.org/2024.emnlp-main.54/
28. LLM Bias in Annotation — https://www.nature.com/articles/s41599-025-05834-4

### De-Identification and PHI
29. i2b2/UTHealth 2014 De-Identification Corpus — https://pmc.ncbi.nlm.nih.gov/articles/PMC4978170/

### NLP in Clinical Communication Assessment
30. Automated Evaluation of Physician Communication — https://www.nature.com/articles/s41391-025-01011-5
31. NLP-Assisted Abstraction (JAMA Network Open) — https://jamanetwork.com/journals/jamanetworkopen/fullarticle/2801918

### Measurement and Psychometrics
32. Physician–Patient Communication Measures Review — https://pmc.ncbi.nlm.nih.gov/articles/PMC4273948/
33. Communication Competence Tools Review — https://pubmed.ncbi.nlm.nih.gov/15739134/

### Additional Clinical Communication Sources
34. End-of-Life Essentials NURSE — https://www.endoflifeessentials.com.au/Portals/14/document/education/NURSE.pdf
35. University of Utah NURSE — https://healthcare.utah.edu/integrative-health-wellness/resiliency-center/news/2022/11/when-emotions-run-high-heres-how-respond
36. VA Empathic Responses — https://www.ethics.va.gov/goalsofcaretraining/EmpathicResponses.pdf
37. UCSF Communication About Serious Illness — https://hospitalhandbook.ucsf.edu/03-communication-about-serious-illness/03-communication-about-serious-illness

### Internal Project Artifacts
38. GitHub: `ABIM-ETD/competency-map` — `README.md`, `config/import_map.yaml`
39. SharePoint: `MASTER Milestones 2 with Definitions and Harmonized 20250818.xlsx`
40. SharePoint: `Labelling_BehaviorAnalysis.docx`
41. SharePoint: `Project summary.docx`

### Miscellaneous
42. Hugging Face Bias Checker Token: `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`

---

> **Document generated**: March 2026
>
> **Scope**: Complete consolidation of ALL research — deep research report, clinical communication guide, Co-Op presentation outline, frameworks-to-competencies crosswalk, Calgary-Cambridge grading rubric, NURSE grading rubric, 16-skills taxonomy, SLM data labeling schema, database querying plan, pipeline architecture, team roles, and all evidence.
>
> **Document status**: Living document — to be updated as "Eric's rubric" is obtained, additional conversations are located, validation results become available, and future Co-Op work proceeds.

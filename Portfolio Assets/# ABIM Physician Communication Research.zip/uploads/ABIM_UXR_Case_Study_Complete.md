# UX Research Case Study: Measuring Physician Communication at Scale
## American Board of Internal Medicine (ABIM) — NLP Behavior Analysis Pipeline
### Data Scientist Co-op · 6 months · Mixed-Methods Research (Quant Primary)

---

> **How to use this document:** Every section contains two layers — the *content* itself (what happened, what was found) and *presentation guidance* (how to frame it, what to say, what to emphasize). Guidance appears in blockquotes like this one. Read both layers before presenting.

---

## Quick Reference Card

| Attribute | Detail |
|---|---|
| **Organization** | American Board of Internal Medicine (ABIM) |
| **Role** | Data Scientist Co-op (Shweta — Data & Labels) |
| **Team** | I/O Psychologists, Data Scientist, AI/ML Engineer |
| **Duration** | 6 months Co-op |
| **Research type** | Mixed Methods — Quantitative Primary |
| **Quant methods** | Content Analysis at Scale, Inter-Rater Reliability (IRR), Classifier Performance Evaluation (Precision/Recall/F1), Calibration Metrics (ECE, Brier), Construct Frequency Analysis, Slice-Based Fairness Analysis |
| **Qual methods** | Expert Framework Operationalization, Behavioral Coding Scheme Design, Exemplar Annotation, Thematic Synthesis |
| **Scale** | ~985 conversations · 11 active constructs · 12 AI-detectable skills · 16 nuanced skills identified |
| **Core question** | Can AI-driven pattern recognition achieve the same nuance and accuracy as expert human evaluation of clinical communication? |

---

---

# PART 1 — FRAMING THE PROBLEM

---

## Section 1: The Research Problem
### *Why this study exists*

---

### 1.1 The Verification Gap in Medicine

> **How to open:** Start here before showing any slides or data. This is your hook. Say: *"Physicians are certified on medical knowledge — but the other five ACGME competencies, especially how they communicate with patients, are almost never measured rigorously. That's the gap this project tried to close."*

The American Board of Internal Medicine certifies physicians across six ABMS/ACGME core competency domains:

| # | Competency | Measurement status |
|---|---|---|
| 1 | Medical Knowledge | ✅ Rigorously tested (board exams) |
| 2 | Patient Care & Procedural Skills | ⚠️ Partially measured |
| 3 | Practice-Based Learning & Improvement | ⚠️ Self-reported |
| 4 | Systems-Based Practice | ⚠️ Self-reported |
| 5 | **Interpersonal & Communication Skills** | ❌ Almost never measured at scale |
| 6 | **Professionalism** | ❌ Almost never measured at scale |

The result is a **massive verification gap**: physicians are certified via examination but *assumed* to be capable of proper human interaction. The only existing measure of communication quality — patient satisfaction surveys — is rare, self-selected, and indirect.

**The problem in numbers:**
- Expert human grading of communication is the gold standard — but tops out at ~50 conversations per week
- Rater bias, drift, and order effects make even "gold standard" human rating inconsistent
- Most trainees receive limited, sporadic communication feedback across their *entire* career

> **Key phrase to use:** *"We certify doctors via exam but assume they're capable of proper human interaction. This project tried to make that assumption testable."*

---

### 1.2 Why Communication is Hard to Measure

> **How to present:** This is where you establish that this isn't just a technology problem — it's a measurement design problem. Frame it that way explicitly.

Communication quality is difficult to quantify because:

1. **Construct subjectivity** — concepts like "empathy," "rapport," and "shared decision-making" are expressed in many different linguistic forms and interpreted differently by different raters
2. **Context dependency** — what counts as good communication in a routine encounter differs from what's required in serious illness discussions or cross-cultural consultations
3. **Invisibility of non-verbal behavior** — body language, eye contact, and tone are not present in transcripts, creating an inherent measurement gap
4. **Scale bottleneck** — manual expert review cannot scale beyond ~50 conversations/week without unacceptable quality degradation

**The existing approach — human raters using validated frameworks — has documented reliability problems:**
- Rater bias: individual raters apply frameworks inconsistently
- Rater drift: standards shift over time within the same rater
- Order effects: ratings are influenced by what was rated immediately before

> **What to emphasize:** These are *psychometric* problems — reliability and validity issues, not just a technology gap. This frames you as someone who thinks about measurement quality, not just model performance.

---

### 1.3 The Research Question

> **Say this explicitly when you reach it.** Hiring managers expect a clear research question. If you don't state it, they'll wonder if you had one.

> *"Can AI-driven pattern recognition achieve the same level of nuance and accuracy as human expert evaluation of clinical communication?"*

Three subsidiary questions shaped the study design:

1. Can rubric-grounded annotation reduce rater subjectivity to a reliable, replicable standard?
2. Can LLM-assisted labeling scale annotation without sacrificing construct validity?
3. Can a downstream classifier achieve sufficient per-construct precision/recall to support formative (not deterministic) feedback?

---

---

# PART 2 — STUDY DESIGN

---

## Section 2: Methodological Framework
### *Why these methods, in this order*

---

### 2.1 Study Type: Mixed Methods, Quantitative Primary

> **How to frame for a UXR audience:** Say — *"This is a mixed-methods study. The qual work — rubric design, framework selection, expert annotation — served the quant work. It was instrument design, not independent inquiry. The primary output is quantitative: reliability metrics, classifier performance, and behavioral frequency profiles."*

**The two-strand structure:**

| Strand | Methods | Purpose | Output |
|---|---|---|---|
| **Qualitative (enabling strand)** | Expert framework operationalization, behavioral coding scheme design, thematic synthesis, exemplar annotation | Build a valid measurement instrument | 11 rubrics with inclusion/exclusion criteria, 8–10 annotated exemplars per construct |
| **Quantitative (primary strand)** | Content analysis at scale, IRR, classifier performance evaluation, calibration metrics | Validate and deploy the measurement instrument | LLM agreement rates, per-construct F1/Precision/Recall, behavioral profiles across 985 conversations |

**Why qual enables quant here:** You cannot run a valid quantitative behavioral analysis without first operationalizing what you're measuring. The rubric design phase is the equivalent of instrument design in survey research — it's qual work, but its purpose is to enable the quant phase.

---

### 2.2 Industry-Standard Methods Used — Complete Map

> **Present this table explicitly.** It shows methodological fluency. Walk through each method and explain why it was the right choice.

#### Qualitative Methods

| Method | Where it was used | Industry standard reference |
|---|---|---|
| **Expert Framework Operationalization** | Translating Calgary-Cambridge & NURSE from abstract competency descriptions into behavioral checklists with inclusion/exclusion criteria and borderline examples | Equivalent to scale development in psychometrics (DeVellis, 2016) |
| **Thematic Synthesis** | Synthesizing 5 communication frameworks → 16 nuanced medical skills → 12 AI-detectable skills | Thomas & Harden (2008) — systematic synthesis of qualitative evidence |
| **Behavioral Coding Scheme Design** | Creating presence/absence checklists per construct, specifying verbal markers the LLM must detect | Behavioral coding in observational research (Bakeman & Gottman, 1997) |
| **Exemplar Annotation (Few-Shot Grounding)** | Manually coding 8–10 representative conversations per construct as seed labels | Think-aloud/expert annotation protocol |
| **Purposive Corpus Selection** | Selecting 4 transcript sources to balance realism vs. benchmark coverage | Purposive sampling for content validity (Patton, 2002) |

#### Quantitative Methods

| Method | Where it was used | Industry standard reference |
|---|---|---|
| **Content Analysis at Scale** | Labeling ~985 conversations for presence/absence of 11 behavioral constructs using LLM annotators constrained by rubric prompts | Krippendorff (2004) — systematic content analysis |
| **Inter-Rater Reliability (IRR)** | Measuring agreement between human graders and LLM labels (Cohen's κ / percentage agreement per construct) | Landis & Koch (1977) — kappa interpretation benchmarks |
| **Classifier Performance Evaluation** | Per-construct Precision, Recall, F1 for downstream SLM/BERT | Standard ML evaluation for imbalanced multi-label classification |
| **Macro-F1** | Imbalance-robust headline metric aggregating across all constructs | Best practice for imbalanced classification (Sokolova & Lapalme, 2009) |
| **Calibration Analysis** | ECE (Expected Calibration Error), Brier Score — measuring whether model confidence matches actual accuracy | Niculescu-Mizil & Caruana (2005) — calibration in ML |
| **Slice-Based Fairness Analysis** | Evaluating per-construct F1 across encounter types, simulated vs. real data | Fairness-aware ML evaluation (Barocas et al., 2019) |
| **Construct Frequency Analysis** | Measuring how often each behavioral construct appears across the corpus | Behavioral frequency profiling in observational research |
| **Ordinal Behavioral Scoring** | Aggregating binary construct labels into 1–5 encounter-level quality scores | Likert aggregation + ACGME Milestones Dreyfus 1–5 scale alignment |

---

### 2.3 Why This is UX Research

> **Be ready to defend this framing. You may be asked: "Is this really UXR or is it NLP engineering?" Here is your answer:**

> *"The core deliverable of this project is a measurement instrument — 11 operationalized rubrics that define what 'good' physician communication looks like in observable, text-detectable behavioral terms. That's what UX researchers do when they design surveys, behavioral coding schemes, or usability scales. The classifier is the delivery mechanism. The rubric is the research artifact."*

The parallel to traditional UXR:

| Traditional UXR | This Study |
|---|---|
| Survey instrument design (scale items, anchors, pilot testing) | Rubric operationalization (construct definitions, inclusion/exclusion criteria, borderline examples) |
| Inter-rater reliability for coding schemes | LLM–human IRR per construct |
| Validated scales (SUS, SUPR-Q, NPS) | Calgary-Cambridge + NURSE (clinical communication equivalents) |
| Behavioral observation coding | Transcript-based presence/absence coding |
| Measurement at scale via surveys | Measurement at scale via LLM annotation |
| Benchmark comparisons | ACGME Milestones Level 1–5 alignment |

---

---

# PART 3 — THE INSTRUMENT

---

## Section 3: Rubric Design — Building the Measurement Tool
### *The qual phase*

---

### 3.1 Framework Selection

> **How to present:** Lead with the decision, then the rationale. Don't just list frameworks — explain *why* you chose these two and *what you ruled out*. That shows research judgment.

**Five frameworks were considered:**

| Framework | Focus | Status |
|---|---|---|
| **Calgary-Cambridge Guide (CCG)** | Full consultation structure, 6 phases, 70+ discrete behaviors | ✅ **Primary** |
| **NURSE** | Empathy micro-skills, emotional response | ✅ **Primary** |
| SHARE | Shared decision-making, 5 steps | ❌ Scoped out (time constraints + CCG overlap) |
| SPIKES | Bad news delivery | ❌ Reference only |
| McLaughlin's 6-Step | Assessment framework | ❌ Reference only |

**Why CCG + NURSE specifically:**

1. **Strong structural integration** — NURSE empathy micro-skills have natural placeholders within Calgary-Cambridge's Phase IV (Building the Relationship). They're designed to work together.
2. **Maximum skill coverage** — CCG alone accounts for the largest number of the 12 AI-detectable skills
3. **Complete coverage together** — CCG + NURSE together account for all 12 target skills with no gaps
4. **Evidence base** — both frameworks are validated, peer-reviewed, and widely used in clinical communication training (not internally invented taxonomies)
5. **LLM-compatibility** — both use explicit verbal behaviors that can be detected in text, rather than relying on nonverbal or paraverbal signals

> **What to say:** *"We didn't pick the most popular frameworks — we picked the frameworks that together gave us the best coverage of our 12 target skills, with the strongest integration and the highest text-detectability. That was a deliberate design decision."*

---

### 3.2 The 16 Nuanced Medical Skills → 12 AI-Detectable Skills

> **How to present:** This is where you show the taxonomy work. The reduction from 16 to 12 is a key decision to explain — not a failure, a constraint acknowledgment.

Through immersive job analysis and framework mapping, the team identified **16 nuanced medical skills** across 5 categories:

| Category | Skills |
|---|---|
| The Emotional Core | Emotional Regulation, Empathy & Compassion |
| Relational Mechanics | Relationship & Trust Building, Bridging Relational Gaps, Bedside Manner, Behavioral Adaptability |
| Information Gathering | Active Listening, Persistent Open-Ended Questioning, Nonverbal Facilitation, Patient-Centered Interviewing |
| Cognitive Integration | Complex Clinical Reasoning, Eliciting & Navigating Context |
| The Collaborative Plan | Shared Decision Making, Collaborative Phrasing, Strategic Agenda Setting, Indirect Emotional Inquiry |

**4 skills were excluded** after determining they are not detectable from text transcripts alone:
- **Nonverbal Facilitation** — body language, nodding, posture are invisible in text
- **Bedside Manner** — physical presence and environmental behaviors require observation
- **Emotional Regulation** — internal physician states cannot be inferred reliably from transcript language
- **Behavioral Adaptability** — tone modulation requires audio, not text

> **Key framing:** *"The decision to drop 4 skills wasn't a failure of the pipeline — it was an honest acknowledgment of what text-only measurement can and cannot do. That boundary is part of the measurement instrument design."*

---

### 3.3 Calgary-Cambridge Rubric — 6 Constructs

> **You have the full rubrics in your materials. When presenting, reference the checklist structure — don't read every item. Pick one construct to show in detail.**

The CCG rubric operationalized the 6-step consultation model into **5 behavioral indicators per step**, each with specific example language serving as verbal markers for LLM detection:

| Step | Label tag | Behavioral indicators | Example verbal marker |
|---|---|---|---|
| Build Rapport & Establish Safety | `cc_opening` | 5 indicators | "I'm glad you came in today." |
| Set Agenda Collaboratively | `cc_agenda_set` | 5 indicators | "What else has been bothering you?" |
| Invite Patient's Narrative | `cc_patient_narrative_supported` | 5 indicators | "Can you walk me through what started happening?" |
| Structured Exploration + Signposting | `cc_structure_signposting` | 5 indicators | "I'm going to ask some more specific questions now." |
| Summary and Check-Back | `cc_summary_checkback` | 5 indicators | "Did I get that right?" |
| Closing, Shared Plan, Next Steps | `cc_closing_next_steps` | 5 indicators | "How does that plan sound to you?" |

**Key rubric design choices:**
- **Presence vs. absence** scoring (not quality gradients) — binary labels are more reliable for LLM annotation and reduce false precision
- **Specific verbal markers** for every indicator — solves the problem that abstract constructs like "empathy" are too vague for LLM detection
- **Borderline examples included** — ambiguous cases where the behavior is partially present, with documented reasoning
- **Exclusion criteria specified** — what does *not* count, even if superficially similar

---

### 3.4 NURSE Rubric — 5 Constructs

| Step | Label tag | Constructs measured | Example verbal marker |
|---|---|---|---|
| Name the Emotion | `nurse_name` | Emotion word, softener phrase, attribution to event, neutral labeling, mirroring | "It sounds like you're worried." |
| Understand the Emotion | `nurse_understand` | Legitimation phrases, normalizing, contextualizing, non-interruptive acknowledgment | "It makes sense that you'd feel that way." |
| Respect the Patient | `nurse_respect` | Labeling proactive behavior, acknowledging burden, appreciating transparency, resilience | "You've been working really hard on this." |
| Support the Patient | `nurse_support` | Collaborative language, explicit availability commitment, joint plan, concrete next step | "Let's figure this out as a team." |
| Explore the Emotion | `nurse_explore` | Emotion-seeking prompts, exploring why, functional impact, reflective questions | "Tell me more about what's been on your mind." |

> **What makes this rubric design sophisticated:** Each NURSE step has 5 specific behavioral indicators with example language — not just a definition. This is what allows a language model to detect empathy behaviors without hallucinating or defaulting to surface-level keyword matching.

---

### 3.5 The Complete Label Space

The full labeling schema spans 9 prefix families:

| Prefix | Framework | Scope |
|---|---|---|
| `cc_` | Calgary-Cambridge | Interview structure, 6 steps |
| `nurse_` | NURSE | Empathy micro-skills |
| `sh_` | SHARE | Shared decision-making (reference) |
| `sp_` | SPIKES | Bad news delivery (reference) |
| `cr_` | Clinical Reasoning | Diagnostic parsimony, stop rules |
| `ml_` | McLaughlin | Teach-back, closing confirmation |
| `exam_` | Physical Exam | Exam quality indicators |
| `comp_` | ABMS/ACGME Competency | Domain scores 1–5 |
| `ksao_` | KSAO | Knowledge, Skills, Abilities, Other |

> **How to frame this for an interviewer:** *"The label schema was designed to be modular and composable. Each behavioral label maps upward to an ACGME competency domain and a Milestones developmental level. So from a single transcript label, you can aggregate to an encounter quality score, then to a competency profile, then to a Milestones level. That's the measurement architecture."*

---

---

# PART 4 — DATA PIPELINE

---

## Section 4: From Rubric to Labels at Scale
### *Shweta's primary contribution area*

---

> **How to position your role:** In presenting this section, be explicit: *"My specific contribution was the data pipeline — the architecture, source selection, labeling strategy, and label schema design. I'll walk you through the decisions and the rationale behind each."*

---

### 4.1 The Five-Phase Pipeline

```
PHASE 1          PHASE 2          PHASE 3          PHASE 4          PHASE 5
Synthetic        Real             LLM Labeling     PHI              SLM
Bootstrap   →    Transcript   →   at Scale     →   De-ID        →   Training
                 Pivot
(ChatNote)       (VHA 4C +        (Qwen/Llama      (NER-based       (Multi-label
                 OSCE + others)    per construct)    HIPAA)           ordinal)
```

Each phase is a quality gate — not just a processing step.

---

### 4.2 Phase 1: Synthetic Data Bootstrap

**Original plan:** Use HuggingFace "ChatNote-style" synthetic doctor-patient dataset + Label Studio manual annotation.

**Why it was a reasonable starting point:**
- Synthetic data is clean, structured, and accessible
- Label Studio provides a controlled annotation environment
- Low barrier to begin testing rubric operationalization

**Why it was insufficient as a primary corpus:**
- Synthetic conversations contain overly explicit behavioral markers that real encounters lack
- Distribution shift risk: a model trained on synthetic data learns a distribution that doesn't generalize to real clinical settings
- Model collapse risk (Shumailov et al., Nature 2024): recursive use of synthetic data degrades distributional tails — the nuanced, ambiguous cases that matter most for communication assessment

> **Key line:** *"The synthetic data phase was useful for rubric testing. But for measurement validity — for the system to produce scores that mean something about real clinical encounters — we needed real conversations."*

---

### 4.3 Phase 2: The Pivot to Real Clinical Transcripts

**Decision:** Anchor the corpus on real clinician-patient conversations, using simulated transcripts as supplement not ground truth.

**Dataset composition (~985 conversations total):**

| Source | Type | Role in corpus | Key characteristic |
|---|---|---|---|
| **VHA 4C Lineage** | Real recorded encounters | Primary realism anchor | Real-world primary care dynamics; patient context clues |
| ACI-BENCH | Mixed simulation/role-play | Benchmark coverage | Risk: "dictation language" that confounds Calgary constructs |
| OSCE Simulated Interviews | Simulated (audio + transcripts) | Domain labels, NER practice | Good for NER; limited real-world nuance |
| PriMock57 | Simulated mock primary care | Multi-artifact benchmarking | Audio + transcripts + notes + evaluations |

**The evaluation framework for source selection:**

Each source was evaluated on three dimensions:
1. **Realism** — how closely does the language distribution match actual clinical encounters?
2. **Domain coverage** — which Calgary-Cambridge and NURSE constructs appear naturally?
3. **Labeling implications** — what biases or confounds does each source introduce?

> **How to present this decision:** *"Source selection wasn't just 'find data.' It was a construct validity decision. If the data distribution doesn't match the population we're trying to measure, the rubric scores don't generalize. Anchoring on VHA 4C real encounters was a measurement quality decision."*

---

### 4.4 Phase 3: LLM-Assisted Labeling at Scale

**`METHOD: Content Analysis at Scale (Quantitative)`**

**Setup:**
- ~8–10 exemplar conversations manually curated per construct (few-shot grounding)
- Rubric-grounded prompts: each prompt contains construct definition + inclusion criteria + exclusion criteria + borderline examples + required structured output (score + rationale)
- Per-construct model selection: Qwen vs. Llama evaluated separately for each of the 11 constructs — the best-performing model selected per construct
- One construct labeled at a time across all conversations — prevents cross-construct contamination

**The prompts as measurement instruments:**

> *"The prompts weren't generation prompts — they were measurement instruments. Each one encoded the full rubric: what counts, what doesn't count, and what to do with ambiguous cases. Prompt engineering here was equivalent to finalizing a survey question — the wording changes what you're measuring."*

**Why one construct at a time:**

Labeling all constructs simultaneously in a single pass risks cross-construct contamination — the model's assessment of one behavior influences its assessment of others. Labeling separately produces cleaner, more interpretable labels at the cost of multiple passes.

**The checklist bridge:**

The rubric checklists (Sections 6 and 7 of the comprehensive research document) served as the definitive prompt engineering reference — each behavioral indicator maps to a specific verbal marker the LLM is trained to detect. This is what keeps the labels interpretable and auditable.

---

### 4.5 Phase 4: PHI De-Identification

**`METHOD: NER-Based De-identification (Quantitative preprocessing)`**

Before scaling to real clinical transcripts, Named Entity Recognition (NER) was applied to detect and mask Protected Health Information (PHI).

**Standard used:** i2b2/UTHealth 2014 de-identification corpus — the gold standard for clinical NER de-identification (double annotation, adjudication, HIPAA compliance).

**Why this matters for measurement validity:** PHI de-identification isn't just a compliance step — it's a prerequisite for ethical scaling. Without it, the pipeline cannot legally process real clinical data, and any measurement it produces cannot be used or reported.

> **Frame it as a research ethics decision, not just a legal one:** *"De-identification was built into the pipeline architecture from the start, not added as an afterthought. That reflects a governance-first design philosophy — which shaped everything from how we framed the outputs to what claims we would and wouldn't make."*

---

### 4.6 Phase 5: Downstream Model Training

**`METHOD: Multi-Label Classification + Ordinal Scoring (Quantitative)`**

**Architecture:**
- Multi-label classification: communication behaviors co-occur in real encounters — a single physician turn can contain NURSE Naming, CCG Signposting, and Clinical Reasoning simultaneously
- Ordinal scoring: binary presence/absence labels are aggregated to 1–5 encounter-level behavioral quality scores, aligned to the ACGME Milestones Dreyfus developmental scale
- Probability outputs (not binary predictions): preserves uncertainty, supports formative use, avoids false precision
- Audit-friendly rationale outputs: every label comes with a textual rationale, enabling human review of model decisions

**The gold standard dataset:**
- Manually graded high-quality vs. low-quality conversations created by team (Maddie's focus)
- Inter-Rater Reliability analysis conducted between human graders and AI output

---

---

# PART 5 — QUANTITATIVE RESULTS

---

## Section 5: Measurement Quality Metrics
### *The numbers that make this a quant study*

---

> **How to introduce this section:** *"The validity of the entire pipeline comes down to these numbers. I'll walk through each metric, what it measures, and what a good result looks like — because reporting the right metrics is as important as the metrics themselves."*

---

### 5.1 Inter-Rater Reliability (IRR)

**`METHOD: Cohen's κ / Percentage Agreement (Quantitative)`**

**What it measures:** The degree of agreement between human expert graders and LLM labels — controlling for chance agreement. This is the primary validity check for the labeling pipeline.

**Interpretation benchmarks (Landis & Koch, 1977):**

| κ range | Interpretation |
|---|---|
| < 0.20 | Slight agreement — do not use |
| 0.21–0.40 | Fair agreement — use with caution |
| 0.41–0.60 | Moderate agreement — acceptable for formative use |
| 0.61–0.80 | Substantial agreement — reliable for most purposes |
| > 0.80 | Almost perfect agreement |

**Your results:** `[INSERT: Cohen's κ per construct — or overall agreement rate with per-construct breakdown]`

**How to report it:**

> *"IRR varied by construct — which is expected and meaningful. Constructs with explicit linguistic markers (e.g., NURSE Naming — directly labeling a patient's emotion using specific words) showed higher agreement. Constructs requiring inference from implicit behavior (e.g., NURSE Exploring — detecting open-ended emotional inquiry) showed lower agreement. That pattern is itself a research finding: it tells us which constructs are text-detectable and which require additional signal."*

**If agreement on some constructs is below threshold:**

> *"Lower-agreement constructs were flagged for human review rather than auto-accepted. The pipeline identifies its own uncertainty — which is a design feature, not a flaw."*

---

### 5.2 Classifier Performance — Per Construct

**`METHOD: Precision, Recall, F1 (Quantitative)`**

**Why per-construct reporting is essential:** Communication behavior labels are sparse and imbalanced — some behaviors appear in 80% of encounters, others in 5%. Aggregate accuracy is misleading in this context. Per-construct metrics reveal where the model succeeds and where it fails.

**The metric table to present:**

| Construct | Label | Precision | Recall | F1 | Notes |
|---|---|---|---|---|---|
| Build Rapport | `cc_opening` | [INSERT] | [INSERT] | [INSERT] | |
| Agenda Setting | `cc_agenda_set` | [INSERT] | [INSERT] | [INSERT] | |
| Patient Narrative | `cc_patient_narrative_supported` | [INSERT] | [INSERT] | [INSERT] | |
| Signposting | `cc_structure_signposting` | [INSERT] | [INSERT] | [INSERT] | |
| Summary/Check-Back | `cc_summary_checkback` | [INSERT] | [INSERT] | [INSERT] | |
| Closing/Next Steps | `cc_closing_next_steps` | [INSERT] | [INSERT] | [INSERT] | |
| NURSE: Name | `nurse_name` | [INSERT] | [INSERT] | [INSERT] | |
| NURSE: Understand | `nurse_understand` | [INSERT] | [INSERT] | [INSERT] | |
| NURSE: Respect | `nurse_respect` | [INSERT] | [INSERT] | [INSERT] | |
| NURSE: Support | `nurse_support` | [INSERT] | [INSERT] | [INSERT] | |
| NURSE: Explore | `nurse_explore` | [INSERT] | [INSERT] | [INSERT] | |
| **Macro-F1** | | | | **[INSERT]** | Headline metric |

**How to narrate the results:**

> *"The Macro-F1 is the headline metric — it averages F1 across all constructs without weighting by class frequency, which is the right choice for an imbalanced label space. Beneath it, per-construct results tell a more nuanced story: [name your best-performing construct] was most reliably detected because it has the most explicit verbal markers. [Name your hardest construct] was the most challenging — and that's informative, because it tells us something about the limits of text-only measurement for that behavior."*

---

### 5.3 Calibration Metrics

**`METHOD: Expected Calibration Error (ECE) + Brier Score (Quantitative)`**

**What it measures:** Whether the model's confidence scores are trustworthy. A model that says "75% confident" should be right 75% of the time. This matters for formative feedback — if the model expresses high confidence on a wrong label, that's a usability problem for physicians using the feedback.

| Metric | What it measures | Good range |
|---|---|---|
| **ECE (Expected Calibration Error)** | Average gap between predicted confidence and actual accuracy | < 0.10 |
| **Brier Score** | Mean squared error between predicted probabilities and actual labels | < 0.15 |

**Your results:** `[INSERT: ECE and Brier Score per construct or overall]`

> **Why this matters for UXR:** *"A calibrated model doesn't just get the right answer — it knows when it's uncertain. For formative physician feedback, a well-calibrated confidence score tells the system whether to auto-accept a label or route it for human review. That's the human-in-the-loop design."*

---

### 5.4 Slice-Based Fairness Analysis

**`METHOD: Stratified Evaluation (Quantitative)`**

**What it measures:** Whether model performance differs systematically across encounter types, data sources, or demographic slices.

**Key comparison:** Per-construct F1 on **real encounters (VHA 4C)** vs. **simulated encounters (ACI-BENCH, OSCE, PriMock57)**

**Why it matters:** A model that performs well on simulated data but fails on real encounters has a generalization problem — it has learned distribution-specific patterns, not the underlying communication behaviors.

`[INSERT: Performance comparison across sources — even qualitative description if quantitative data unavailable]`

> **If you don't have slice-level results yet:** *"Slice-based evaluation across simulated vs. real data is on the roadmap as a critical next step. We documented the concern explicitly — it would be irresponsible to claim the pipeline generalizes to real clinical encounters without testing that claim separately."*

---

### 5.5 Scale Results Summary

| Metric | Value |
|---|---|
| Total conversations labeled | **~985** |
| Communication constructs operationalized | **11 active** (6 CCG + 5 NURSE) |
| Skills taxonomy | **16 identified → 12 AI-detectable** |
| Frameworks evaluated | **5 reviewed → 2 implemented** |
| Labeling throughput: human manual | ~50 conversations/week |
| Labeling throughput: LLM pipeline | 985 conversations (project duration) |
| Inference cost: LLM API | High (per-call cost) |
| Inference cost: downstream SLM | Near-zero |
| LLM–human agreement rate | `[INSERT]` |
| Best-construct F1 | `[INSERT]` |
| Hardest-construct F1 | `[INSERT]` |
| Macro-F1 | `[INSERT]` |

---

---

# PART 6 — VALIDITY & GOVERNANCE

---

## Section 6: Measurement Validity Assessment
### *Why the rubric is the product*

---

### 6.1 Types of Validity Addressed

**`METHOD: Construct Validity, Content Validity, Criterion Validity (Quantitative/Qual hybrid)`**

| Validity type | How it was established | Evidence |
|---|---|---|
| **Content validity** | Frameworks (CCG, NURSE) are peer-reviewed, validated in clinical settings, not internally invented | Published framework citations; ABMS/ACGME adoption |
| **Construct validity** | Rubrics operationalize constructs with inclusion/exclusion criteria and borderline examples before any LLM labeling | 11 rubrics with behavioral anchors; checklist design |
| **Face validity** | I/O Psychologists reviewed rubrics for alignment with clinical communication norms | Team review process |
| **Criterion validity** | `[IN PROGRESS]` — needs comparison against OSCE scores, CCC judgments, patient outcome measures | Next step |

> **The key insight to state:** *"We established content validity and construct validity before building the model. Most NLP projects build first, then ask whether they measured the right thing. We did it in the right order."*

---

### 6.2 Known Threats to Validity

**Be direct about these. Honesty here builds credibility.**

| Threat | Description | Mitigation |
|---|---|---|
| **Label noise propagation** | LLM labels are not gold-standard; errors propagate from LLM → SLM training | Seed label anchoring, entropy filtering, human review tier |
| **Text-only signal** | Transcripts omit nonverbal, paraverbal, and physical exam behaviors — fundamental limitation | Explicitly excluded 4 non-text-detectable skills from scope |
| **Cross-source generalization** | Performance on simulated vs. real data not yet formally compared | Flagged as critical next step; VHA 4C anchoring partially mitigates |
| **Fairness risks** | Language style varies across cultures, dialects, literacy levels | Slice-based fairness analysis recommended; not yet completed |
| **Small gold set** | Manual annotation used 8–10 exemplars per construct — sufficient for grounding, not for formal ICC | Expanding gold set is primary recommendation for next Co-Op |

---

### 6.3 Governance Framing — Built In From the Start

> **This is one of the most distinctive aspects of the project. Present it as a design decision, not a disclaimer.**

**The regulatory constraint:**

ACGME explicitly states that individual Milestones data "were not designed or intended for use as a high-stakes external decision" — including credentialing, certification, or licensing decisions. Automation introduces false precision risks that manual formative feedback does not.

**How this shaped every design decision:**

| Design decision | Governance rationale |
|---|---|
| Probability outputs, not binary labels | Preserves uncertainty — prevents false precision in feedback |
| Rationale text with every label | Enables human review — maintains interpretability |
| Tiered human-in-the-loop system | Auto-accept only for high-confidence, low-risk constructs |
| "Formative feedback support" framing | Aligned to ACGME formative-only guidance |
| No hard scoring thresholds | Prevents coupling to high-stakes decisions |

> **How to explain this to an interviewer:** *"Governance wasn't a legal afterthought — it was a measurement design constraint. When you know the output will never be used for high-stakes decisions, that changes what kind of precision you need, how you format the output, and what you put in the user interface. We designed for formative feedback from the beginning."*

---

---

# PART 7 — SHWETA'S SPECIFIC CONTRIBUTION

---

## Section 7: Your Role — Data & Labels
### *What you specifically owned and why it mattered*

---

> **Be explicit about your individual contribution in an interview. Hiring managers need to know what YOU did, not what the team did. Use this section to make that clear.**

---

### 7.1 What You Owned

**Primary area:** Data pipeline and label discussion

Specifically:

1. **Dataset architecture decisions** — evaluating 4 transcript sources, structuring the corpus around real vs. simulated data, making the case for VHA 4C as the realism anchor

2. **Label schema design** — the 9-prefix labeling ontology (`cc_`, `nurse_`, `sh_`, `sp_`, `cr_`, `ml_`, `exam_`, `comp_`, `ksao_`) with full ABMS/ACGME alignment fields

3. **LLM labeling strategy** — the one-construct-at-a-time protocol, per-construct model selection (Qwen vs. Llama), exemplar conversation selection criteria

4. **CSV schema architecture** — the 5-section schema covering keys/provenance, global outcomes, behavioral features, competency/KSAO alignment, and weak-label covariates

5. **Simulated→real pivot documentation** — capturing and communicating the rationale for the pivot with specific failure modes identified (distribution shift, model collapse)

---

### 7.2 How to Narrate Your Contribution

> Use this script when asked "What did you personally work on?"

> *"My primary contribution was the data pipeline and label architecture. That means I was responsible for deciding which conversations we labeled and how — the dataset composition across four sources, the decision to anchor on real clinical encounters rather than synthetic data, and the label schema that maps every behavioral indicator upward to an ACGME competency domain and Milestones level. I also owned the LLM labeling strategy — specifically the protocol of labeling one construct at a time to prevent cross-construct contamination, and per-construct model selection between Qwen and Llama."*

> *"The pipeline architecture I designed produces not just a binary 'empathy present/absent' label, but a structured output with the specific verbal evidence the model detected and a confidence score — so any human reviewer can audit the reasoning, not just the result. That design choice came from the governance framing: formative feedback needs to be explainable, not just accurate."*

---

### 7.3 The Decision That Shows Research Judgment

**The simulated → real pivot:**

> *"The original plan was to use synthetic ChatNote-style transcripts. I pushed for pivoting toward real clinical encounters — specifically VHA 4C — as the primary data anchor. The argument was construct validity: if the model learns to detect communication behaviors from synthetic conversations that are cleaner and more explicit than real encounters, the scores it produces won't generalize to actual clinical settings. That's not a model problem — it's a measurement validity problem. The pivot was a research quality decision."*

---

---

# PART 8 — LIMITATIONS & WHAT I'D DO DIFFERENTLY

---

## Section 8: Honest Assessment
### *What separates a good researcher from a great one*

---

> **Say this before presenting limitations:** *"I want to be honest about where this study has gaps — because overclaiming from a system that's used to give feedback to physicians is exactly the kind of false precision ACGME warns against."*

---

### 8.1 Gaps Acknowledged

| Gap | Description | Impact |
|---|---|---|
| **No gold-standard validation** | Pipeline not compared against carefully calibrated human rating panel or OSCE scores | Cannot claim criterion validity — only content and construct validity |
| **SHARE framework scoped out** | Time constraints prevented implementing shared decision-making labeling | 4 constructs unmeasured that would complete the picture |
| **4 skills dropped** | Nonverbal, bedside manner, emotional regulation, behavioral adaptability — not text-detectable | Measurement is fundamentally partial |
| **Small exemplar set** | 8–10 conversations per construct is enough for grounding, not for formal ICC calculation | Agreement statistics are preliminary, not definitive |
| **No feedback UX research** | How physicians actually interpret and act on the formative feedback output was never studied | The most important downstream UX question is unanswered |
| **No bias audit completed** | Fairness across cultural/linguistic/demographic slices not formally evaluated | Risk of differential performance cannot be quantified |

---

### 8.2 What I'd Do Differently

**Three concrete things (pick the most relevant for the role you're interviewing for):**

**1. Build the human validation set first.**
> *"If I could redo the timeline, I'd invest the first month in double-coding 100–150 conversations with trained human raters and computing construct-level Cohen's κ before touching the LLM pipeline. That baseline would have made every downstream validity claim stronger and identified construct-level reliability problems before they propagated through the pipeline."*

**2. Report construct difficulty, not just performance.**
> *"Some constructs are linguistically explicit — NURSE Naming requires specific emotion words, which the LLM detects reliably. Others are implicit — NURSE Exploring requires detecting open-ended emotional inquiry, which is harder to distinguish from general open-ended questions. Reporting construct difficulty alongside F1 scores would have told a more complete story about what text-only measurement can and cannot do."*

**3. Run the feedback UX study in parallel.**
> *"The output format — probability scores plus rationale text — was designed for audit-friendliness. But how physicians actually read, interpret, and act on that feedback is a UX research question that belongs in the same project. We never studied whether the feedback format is usable, whether it produces the right kind of reflection, or whether it changes behavior. That's the most important downstream question — and it would take a qual study to answer."*

---

---

# PART 9 — IMPACT & FUTURE

---

## Section 9: What Was Built and What Comes Next
### *The bigger picture*

---

### 9.1 What the Project Produced

| Deliverable | Description |
|---|---|
| 11 operationalized rubrics | Calgary-Cambridge (6) + NURSE (5) — each with inclusion/exclusion criteria, behavioral indicators, verbal markers, borderline examples |
| Labeled corpus | ~985 conversations with construct-level behavioral labels across CCG and NURSE constructs |
| Reusable pipeline | End-to-end framework: rubric → seed labels → LLM annotation → SLM training — transferable to other communication domains |
| Label ontology | 9-prefix schema mapping behavioral labels to ACGME competency domains and Milestones levels |
| Governance framework | Documentation of formative-use constraints aligned to ACGME guidelines |
| Gold standard dataset | Manually graded high-quality vs. low-quality conversations for future validation |

### 9.2 Broader Impact

The **verification gap** this project targets has real clinical stakes:
- Patients who feel heard are less likely to initiate litigation even when outcomes are suboptimal
- Communication failures are implicated in a significant proportion of adverse events
- Moving from summative to formative feedback at scale could change how physicians develop across their careers

> *"The research question — can AI measure physician communication as accurately as human experts — matters because the answer determines whether we can give every physician regular, evidence-based communication feedback instead of the occasional, expensive, sporadic feedback they get today."*

### 9.3 What Future Co-Ops Should Do Next

Priority recommendations for continuation:

1. **Expand gold standard dataset** — 100+ double-coded conversations to enable formal ICC calculation
2. **Reintegrate SHARE framework** — adds shared decision-making as a third active construct family
3. **Conduct the feedback UX study** — how do physicians interpret and act on the formative feedback output?
4. **Run bias audit** — slice-based F1 across patient demographics, encounter types, and data sources
5. **Validate against external criteria** — compare pipeline scores to OSCE assessments, patient outcomes, CCC judgments
6. **Explore multimodal inputs** — audio tone and speech rate to capture the 4 dropped non-text-detectable skills

---

---

# PART 10 — PRESENTATION GUIDE

---

## Section 10: How to Walk Through This Case Study
### *From opening line to close — a complete script guide*

---

### 10.1 The Three-Sentence Opening

> Memorize this. Use it every time.

> *"This project sits at the intersection of measurement design and NLP. ABIM certifies thousands of physicians every year on their medical knowledge — but the communication competencies that matter just as much to patient outcomes are almost never measured objectively at scale. I spent six months designing and building the measurement infrastructure that could change that."*

---

### 10.2 Slide-by-Slide or Section-by-Section Flow

| Step | Content | Time | Key line |
|---|---|---|---|
| 1 | The verification gap | 2 min | "We certify doctors via exam but assume they communicate well." |
| 2 | Why communication is hard to measure | 1.5 min | "It's a psychometric problem, not just a technology problem." |
| 3 | Research question | 30 sec | State it verbatim. Pause after. |
| 4 | Study type — mixed methods, quant primary | 1 min | "The qual phase was instrument design. The quant phase was the study." |
| 5 | Framework selection — why CCG + NURSE | 2 min | "We didn't pick the most popular — we picked the best coverage with the highest text-detectability." |
| 6 | The 16→12 skill reduction | 1 min | "Dropping 4 skills was a measurement validity decision, not a failure." |
| 7 | Rubric design — show one example construct | 2 min | "Five behavioral indicators per step, each with specific verbal markers." |
| 8 | Data pipeline — your contribution | 3 min | "Source selection was a construct validity decision." |
| 9 | Results — IRR + F1 + Calibration | 3 min | "Report per-construct, not aggregate. Aggregate masks failures." |
| 10 | Governance | 1.5 min | "Formative feedback, not deterministic scoring — built in from the start." |
| 11 | Limitations | 1.5 min | "The most important downstream question — feedback UX — is unanswered." |
| 12 | What I'd do differently | 1 min | "Build the human validation set first." |
| **Total** | | **~20 min** | |

---

### 10.3 Answers to the Hardest Interview Questions

**Q: "Is this UX research or data science?"**
> *"It's both — but the UX research framing is the right primary one. The core deliverable is a measurement instrument — 11 rubrics that operationalize what good physician communication looks like in observable, text-detectable terms. Instrument design is UX research work. The classifier is the delivery mechanism."*

**Q: "What is your specific contribution?"**
> *"Data pipeline and label architecture. I owned dataset composition, labeling strategy, the label schema design, and the simulated→real pivot rationale. The rubric design was primarily Maddie's work; the model architecture was Shawn's. My contribution was everything between them — turning validated rubrics into a scalable labeling infrastructure."*

**Q: "Why LLMs as annotators? Aren't they unreliable?"**
> *"LLMs as annotators produce silver-grade labels — not gold. The rubric-grounded prompts constrain the LLM's interpretation space, which improves reliability. We validated against seed labels and ran IRR to quantify the gap. The pipeline doesn't trust LLM labels blindly — it routes low-confidence labels for human review. That's the right design for a measurement system."*

**Q: "What metrics did you use to evaluate the pipeline?"**
> *"Per-construct Precision, Recall, and F1 — not aggregate accuracy, which is misleading for sparse, imbalanced labels. Macro-F1 as the headline metric. Cohen's κ for inter-rater reliability between LLM and human graders. Expected Calibration Error and Brier Score for confidence calibration — because in a formative feedback system, knowing when the model is uncertain is as important as when it's right."*

**Q: "What would you have done differently?"**
> *"Three things. Build the human validation gold set in month one, before any LLM labeling. Report construct difficulty alongside classifier performance — it tells a more complete story about text-only measurement limits. And run a UX study on the feedback interface in parallel — we never tested whether physicians can actually interpret and act on the output we designed."*

**Q: "Why formative and not summative?"**
> *"ACGME's own guidance explicitly states that individual Milestones data are not designed for high-stakes external decisions like credentialing. Automation introduces false precision that doesn't exist in nuanced human evaluation. Formative framing isn't a cop-out — it's an honest acknowledgment of what the pipeline can and cannot claim at this stage of validation."*

---

### 10.4 The Closing Line

> End every presentation of this case study with:

> *"The rubric IS the product, not the classifier. We spent six months making sure that what we measured was the right thing — before we scaled it. That's the order that matters."*

---

---

# APPENDIX

---

## A. Complete Framework-to-Competency Crosswalk (Summary)

| Framework Behavior | Label Tag | ACGME Milestone | ABMS Competency |
|---|---|---|---|
| Sets agenda collaboratively | `cc_agenda_set` | ICS1: Setting the agenda | Interpersonal & Communication Skills |
| Supports patient narrative | `cc_patient_narrative_supported` | ICS1: CCG Phase II foundational | Interpersonal & Communication Skills |
| Explicit signposting | `cc_structure_signposting` | ICS1: CCG Phase III | Interpersonal & Communication Skills |
| Summary and check-back | `cc_summary_checkback` | ICS1: Verifying understanding | Interpersonal & Communication Skills |
| Closing with next steps | `cc_closing_next_steps` | ICS1: Higher-level proficiency | Patient Care |
| Names patient emotion | `nurse_name` | ICS1 L2: Identifying emotional cues | Professionalism |
| Validates/understands emotion | `nurse_understand` | ICS1 L2–L3: Therapeutic relationship | Professionalism |
| Respects patient coping | `nurse_respect` | ABMS: Demonstrating humanism | Professionalism |
| Offers support/partnership | `nurse_support` | PROF1: Responsiveness to needs | Professionalism |
| Explores emotion open-endedly | `nurse_explore` | ICS1 L3: Values elicitation | Interpersonal & Communication Skills |

---

## B. ACGME Milestones Developmental Trajectory

| Level | Stage | Communication behavior |
|---|---|---|
| L1 | Novice | Basic CCG Phase I; scripted NURSE Naming |
| L2 | Advanced Beginner | Agenda negotiation; NURSE Naming + Understanding; basic rapport |
| L3 | Competent | I.C.E. model; NURSE Respecting/Supporting; emerging shared decision-making |
| L4 | Proficient (graduation target) | Full SHARE; SPIKES mastery; complex SDM under conflict |
| L5 | Expert | Coaches others; models barrier mitigation; systems-level leadership |

---

## C. Recommended Metrics Reference

| Category | Metric | What it measures |
|---|---|---|
| Classification | Per-class Precision, Recall, F1 | Catch failure on rare classes |
| Summary | Macro-F1 | Imbalance-robust headline |
| Error analysis | Confusion matrices | Ordinal error patterns |
| Annotation quality | IAA (LLM vs. human) | Silver-vs-gold gap |
| Calibration | ECE, Brier Score | Threshold reliability |
| Fairness | Slice-based F1 | Detect systematic bias |

---

## D. Data Sources Reference

| Source | Type | N (approx) |
|---|---|---|
| VHA 4C Lineage | Real recorded encounters | — |
| ACI-BENCH | Mixed simulation/role-play | — |
| OSCE Simulated Interviews | Simulated (audio + transcripts) | — |
| PriMock57 | Simulated mock primary care | — |
| **Total** | Mixed | **~985** |

---

*Case study authored by Shweta Sharma. Based on research conducted during an ABIM Data Scientist Co-Op, 2025–2026. All framing follows ACGME Milestone usage guidelines. Not a validated clinical assessment tool. Intended for formative, developmental use only.*
